package com.kayroot.engine

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Regression tests for the bounded process runner (CI runs on Linux). */
class ShellTest {
    @Test fun capturesStdoutAndExitCode() {
        val result = Shell.run(arrayOf("sh", "-c", "printf 'kayroot-ok'"), 5_000)
        assertEquals("0", result[0])
        assertEquals("kayroot-ok", result[1].trim())
    }

    @Test fun preservesNonZeroExitCodeAndStderr() {
        val result = Shell.run(arrayOf("sh", "-c", "echo failure >&2; exit 7"), 5_000)
        assertEquals("7", result[0])
        assertTrue(result[2].contains("failure"))
    }

    @Test fun timesOutLongRunningProcess() {
        val result = Shell.run(arrayOf("sh", "-c", "sleep 3"), 100)
        assertEquals("124", result[0])
        assertTrue(result[2].contains("timeout"))
    }
}
