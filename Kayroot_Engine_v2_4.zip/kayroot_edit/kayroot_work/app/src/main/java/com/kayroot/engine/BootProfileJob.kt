package com.kayroot.engine

import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.app.job.JobService
import android.content.ComponentName
import android.content.Context

/** Applies the saved profile after boot without holding a BroadcastReceiver open during a delay. */
class BootProfileJob : JobService() {
    companion object {
        const val JOB_ID = 4203

        fun schedule(context: Context) {
            try {
                val scheduler = context.getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler
                val job = JobInfo.Builder(JOB_ID, ComponentName(context, BootProfileJob::class.java))
                    .setMinimumLatency(15_000L)
                    .setOverrideDeadline(60_000L)
                    .build()
                scheduler.schedule(job)
            } catch (_: Exception) {
                OpLog.add(context, "Boot profile schedule failed", false)
            }
        }
    }

    override fun onStartJob(params: JobParameters): Boolean {
        Thread {
            try {
                val prefs = getSharedPreferences("kayroot", MODE_PRIVATE)
                val access = AccessManager(this)
                val profile = prefs.getString("last_profile", null)
                if (prefs.getBoolean("boot_apply", true) && access.mode == Mode.ROOT && !profile.isNullOrBlank()) {
                    val result = Tweaks(this, access).profile(profile)
                    OpLog.add(this, "Boot profile applied: $profile", result.errno == 0)
                }
            } catch (e: Exception) {
                OpLog.add(this, "Boot profile apply failed: " + (e.message ?: "error"), false)
            } finally {
                jobFinished(params, false)
            }
        }.start()
        return true
    }

    override fun onStopJob(params: JobParameters): Boolean = true
}
