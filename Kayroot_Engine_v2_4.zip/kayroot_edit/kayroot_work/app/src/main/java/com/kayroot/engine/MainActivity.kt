package com.kayroot.engine

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.HapticFeedbackConstants
import android.webkit.JavascriptInterface
import android.webkit.JsResult
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject
import rikka.shizuku.Shizuku
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private lateinit var web: WebView
    private lateinit var access: AccessManager
    private lateinit var tweaks: Tweaks
    private lateinit var features: Features
    private lateinit var api: Api
    /** True only while the page loaded in the WebView is our own bundled UI. Every bridge call checks it. */
    @Volatile private var trusted = false
    private val ASSET_PREFIX = "file:///android_asset/webroot/"
    private val io = Executors.newSingleThreadExecutor()
    private val fast = Executors.newSingleThreadExecutor()   // status pushes must never wait behind long tweaks

    private val binderReceived = Shizuku.OnBinderReceivedListener { pushStatus() }
    private val binderDead = Shizuku.OnBinderDeadListener { pushStatus() }
    private val permResult = Shizuku.OnRequestPermissionResultListener { _, result ->
        if (result == PackageManager.PERMISSION_GRANTED) {
            access.mode = Mode.SHIZUKU
            io.execute { access.execScript("echo warmup") } // bind the user service early
            toast("Shizuku connected - Pro features unlocked", "success")
        } else {
            toast("Shizuku permission denied", "error")
        }
        pushStatus()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        CrashLog.install(this)
        BatteryHistoryJob.schedule(this)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK

        access = AccessManager(this)
        tweaks = Tweaks(this, access)
        features = Features(this, access, tweaks)
        api = Api(this, access, tweaks, features)

        web = WebView(this)
        web.setBackgroundColor(Color.BLACK)
        web.isLongClickable = true     // lets users long-press to copy values (cards stay non-selectable via CSS)
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true       // localStorage (theme, settings)
            allowFileAccess = false        // Bundled assets remain available; arbitrary file access is disabled.
            allowContentAccess = false
            allowFileAccessFromFileURLs = false
            allowUniversalAccessFromFileURLs = false
            mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) safeBrowsingEnabled = true
        }
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url
                if (isTrustedAssetUrl(u.toString())) return false
                // Never navigate the privileged WebView to an external or untrusted document.
                if (isAllowedExternalUri(u)) openExternal(u.toString())
                else toast("Blocked unsupported link type", "error")
                return true
            }

            override fun onPageStarted(view: WebView, url: String, favicon: android.graphics.Bitmap?) {
                trusted = isTrustedAssetUrl(url)
            }

            override fun onPageFinished(view: WebView, url: String) = pushStatus()
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onJsAlert(view: WebView, url: String, message: String, result: JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity)
                    .setMessage(message)
                    .setPositiveButton(android.R.string.ok) { _, _ -> result.confirm() }
                    .setOnCancelListener { result.cancel() }
                    .show()
                return true
            }
        }
        web.addJavascriptInterface(AppApi(), "KayrootApp")
        setContentView(web)
        web.loadUrl("file:///android_asset/webroot/index.html")

        try {
            Shizuku.addBinderReceivedListenerSticky(binderReceived)
            Shizuku.addBinderDeadListener(binderDead)
            Shizuku.addRequestPermissionResultListener(permResult)
        } catch (_: Throwable) {}

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7)
        }

        io.execute { tweaks.restoreGovernor(); api.resumePending() }
        // bring Auto AI back if the system killed it
        if (getSharedPreferences("kayroot", MODE_PRIVATE).getBoolean("ai_on", false) && access.mode != Mode.BASIC) {
            AutoAiService.start(this)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // let the web UI close a sheet / dialog or go back to Home first; exit only from Home
        web.evaluateJavascript("(window.kayrootBack && window.kayrootBack()) === true") { r ->
            if (r != "true") runOnUiThread { super@MainActivity.onBackPressed() }
        }
    }

    override fun onResume() {
        super.onResume()
        if (::web.isInitialized) pushStatus()
    }

    override fun onDestroy() {
        try {
            Shizuku.removeBinderReceivedListener(binderReceived)
            Shizuku.removeBinderDeadListener(binderDead)
            Shizuku.removeRequestPermissionResultListener(permResult)
        } catch (_: Throwable) {}
        trusted = false
        io.shutdownNow()
        fast.shutdownNow()
        web.stopLoading()
        web.removeJavascriptInterface("KayrootApp")
        web.destroy()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ helpers
    private fun js(code: String) = web.post { web.evaluateJavascript(code, null) }

    private fun pushStatus() {
        fast.execute {
            val json = api.status().toString()
            js("window.onKayrootStatus && window.onKayrootStatus($json)")
        }
    }

    private fun toast(msg: String, type: String) =
        js("typeof toast==='function' && toast(${JSONObject.quote(msg)},'$type')")

    private fun isTrustedAssetUrl(url: String): Boolean {
        // The bridge is trusted only for the bundled UI path; reject traversal encodings.
        return url.startsWith(ASSET_PREFIX) &&
            !url.contains("%2e", ignoreCase = true) &&
            !url.contains("/../") &&
            !url.contains("\\")
    }

    private fun isAllowedExternalUri(uri: Uri): Boolean =
        uri.scheme?.lowercase() in setOf("https", "http", "mailto", "tel", "upi")

    private fun openExternal(url: String) = runOnUiThread {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (_: Exception) { toast("No app found to open this link", "error") }
    }

    // ------------------------------------------------------------------ JS bridge
    inner class AppApi {
        @JavascriptInterface
        fun getStatus(): String = api.status().toString()

        @JavascriptInterface
        fun getStats(): String = features.stats().toString()

        @JavascriptInterface
        fun haptic() {
            runOnUiThread { window.decorView.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP) }
        }

        /** Opens Android's share sheet with plain text (used to export a backup or the crash log). */
        @JavascriptInterface
        fun shareText(title: String, text: String) {
            if (!trusted || text.length > 400_000) return
            runOnUiThread {
                try {
                    val send = Intent(Intent.ACTION_SEND).setType("text/plain")
                        .putExtra(Intent.EXTRA_SUBJECT, title.take(80)).putExtra(Intent.EXTRA_TEXT, text)
                    startActivity(Intent.createChooser(send, title.take(80)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (e: Exception) { toast("Cannot share: ${e.message}", "error") }
            }
        }

        /** Clipboard text, only read when the user taps "Paste" in the restore dialog. */
        @JavascriptInterface
        fun readClipboard(): String {
            if (!trusted) return ""
            var out = ""
            val latch = java.util.concurrent.CountDownLatch(1)
            runOnUiThread {
                try {
                    val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    out = cm.primaryClip?.getItemAt(0)?.coerceToText(this@MainActivity)?.toString().orEmpty().take(200_000)
                } catch (_: Exception) {}
                latch.countDown()
            }
            latch.await(2, java.util.concurrent.TimeUnit.SECONDS)
            return out
        }

        @JavascriptInterface
        fun openShizuku() {
            if (!trusted) return
            val i = packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
            if (i != null) runOnUiThread { startActivity(i) }
            else openExternal("https://github.com/RikkaApps/Shizuku/releases")
        }

        /** Generic async call: result JSON is passed to window[callback](result). */
        @JavascriptInterface
        fun call(action: String, args: String, callback: String) {
            if (!trusted || args.length > 200_000) return
            io.execute {
                val out = try {
                    api.handle(action, JSONObject(if (args.isBlank()) "{}" else args))
                } catch (e: Exception) {
                    JSONObject().put("ok", false).put("msg", e.message ?: "error")
                }
                val cb = callback.filter { it.isLetterOrDigit() || it == '_' }
                js("window['$cb'] && window['$cb']($out)")
                pushStatus()
            }
        }

        /** Same as call() but on a separate thread so live monitoring never waits behind long tweaks. */
        @JavascriptInterface
        fun fastCall(action: String, args: String, callback: String) {
            if (!trusted || args.length > 200_000) return
            fast.execute {
                val out = try {
                    api.handle(action, JSONObject(if (args.isBlank()) "{}" else args))
                } catch (e: Exception) {
                    JSONObject().put("ok", false).put("msg", e.message ?: "error")
                }
                val cb = callback.filter { it.isLetterOrDigit() || it == '_' }
                js("window['$cb'] && window['$cb']($out)")
            }
        }

        /** Opens the matching Android settings page (the user grants permissions there, never silently). */
        @JavascriptInterface
        fun openSystem(kind: String) {
            if (!trusted) return
            runOnUiThread {
                try {
                    val i = when (kind) {
                        "overlay" -> Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                        "notif" -> Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                            .putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, packageName)
                        "battery" -> Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                        else -> return@runOnUiThread
                    }
                    startActivity(i)
                } catch (e: Exception) { toast("Cannot open settings: ${e.message}", "error") }
            }
        }

        @JavascriptInterface
        fun selectMode(m: String) {
            if (!trusted) return
            when (m) {
                "basic" -> { access.mode = Mode.BASIC; toast("Basic mode active", "info"); pushStatus() }
                "shizuku" -> selectShizuku()
                "root" -> io.execute {
                    toast("Checking root access...", "info")
                    if (access.checkRoot()) {
                        access.mode = Mode.ROOT
                        toast("Root access granted - full features unlocked", "success")
                    } else {
                        toast("Root not available on this device", "error")
                    }
                    pushStatus()
                }
            }
        }
    }

    private fun selectShizuku() {
        if (!access.shizukuInstalled()) {
            toast("Shizuku is not installed. Opening download page...", "error")
            openExternal("https://github.com/RikkaApps/Shizuku/releases")
            return
        }
        if (!access.shizukuRunning()) {
            toast("Start Shizuku first (Wireless debugging), then tap Shizuku again", "error")
            packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")?.let {
                runOnUiThread { startActivity(it) }
            }
            return
        }
        if (access.shizukuGranted()) {
            access.mode = Mode.SHIZUKU
            io.execute { access.execScript("echo warmup") }
            toast("Shizuku connected - Pro features unlocked", "success")
            pushStatus()
        } else {
            runOnUiThread {
                try { Shizuku.requestPermission(100) } catch (e: Throwable) { toast("Shizuku error: ${e.message}", "error") }
            }
        }
    }
}
