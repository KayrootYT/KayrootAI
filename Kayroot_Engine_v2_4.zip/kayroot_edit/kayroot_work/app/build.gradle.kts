plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// CI uses the same private release keystore on every distributable release.
// Without secrets, Gradle's debug key is used only to produce a development/test APK.
val ksPath: String? = System.getenv("KEYSTORE_PATH")
val hasKeystore = ksPath != null && file(ksPath).exists()

android {
    namespace = "com.kayroot.engine"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.kayroot.engine"
        minSdk = 26
        targetSdk = 34
        versionCode = 24
        versionName = "2.4"
    }

    buildFeatures {
        aidl = true
        buildConfig = true
    }

    signingConfigs {
        if (hasKeystore) {
            create("release") {
                storeFile = file(ksPath!!)
                storePassword = System.getenv("KEYSTORE_PASSWORD")
                keyAlias = System.getenv("KEY_ALIAS")
                keyPassword = System.getenv("KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = if (hasKeystore) signingConfigs.getByName("release")
                            else signingConfigs.getByName("debug")
        }
    }

    lint {
        // CI must fail on lint errors instead of silently shipping a broken release.
        abortOnError = true
        checkReleaseBuilds = true
        warningsAsErrors = false
        checkTestSources = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("dev.rikka.shizuku:api:13.1.5")
    implementation("dev.rikka.shizuku:provider:13.1.5")

    // JVM unit tests for the pure logic (AutoAiRules). org.json:json replaces Android's stubbed org.json on the test classpath.
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.json:json:20231013")
}
