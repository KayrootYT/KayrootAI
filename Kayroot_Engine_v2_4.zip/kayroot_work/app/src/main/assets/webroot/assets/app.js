/* Kayroot Engine UI v3 - talks to the Android backend through window.KayrootApp */
(function () {
'use strict';
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const store = {
  get: (k, d) => { try { const v = localStorage.getItem('kr_' + k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } },
  set: (k, v) => { try { localStorage.setItem('kr_' + k, JSON.stringify(v)); } catch (e) {} }
};

/* ---------------------------------------------------------------- bridge (+ browser mock for previews) */
const hasNative = !!window.KayrootApp;
if (!hasNative) installMock();
let cbN = 0;
function call(action, args) {
  return new Promise(resolve => {
    const cb = 'kcb' + (++cbN);
    const t = setTimeout(() => { delete window[cb]; resolve({ ok: false, msg: 'Timeout' }); }, 120000);
    window[cb] = r => { clearTimeout(t); delete window[cb]; resolve(r); };
    try { KayrootApp.call(action, JSON.stringify(args || {}), cb); }
    catch (e) { clearTimeout(t); resolve({ ok: false, msg: String(e) }); }
  });
}
function callFast(action, args) {
  return new Promise(resolve => {
    const cb = 'kfb' + (++cbN);
    const t = setTimeout(() => { delete window[cb]; resolve({ ok: false, msg: 'Timeout' }); }, 20000);
    window[cb] = r => { clearTimeout(t); delete window[cb]; resolve(r); };
    try { KayrootApp.fastCall(action, JSON.stringify(args || {}), cb); }
    catch (e) { clearTimeout(t); resolve({ ok: false, msg: String(e) }); }
  });
}
const native = (fn, ...a) => { try { return KayrootApp[fn](...a); } catch (e) { return null; } };
const haptic = () => { if (store.get('haptic', true)) native('haptic'); };

/* ---------------------------------------------------------------- helpers */
const esc = x => String(x).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fmtAgo = t => { if (!t) return 'never'; const m = Math.round((Date.now() - t) / 60000); return m < 1 ? 'just now' : m < 60 ? m + ' min ago' : m < 1440 ? Math.round(m / 60) + ' h ago' : Math.round(m / 1440) + ' d ago'; };
const na = (v, f) => (v === null || v === undefined) ? null : f(v);
const tint = (hex, a) => { const n = parseInt(hex.slice(1), 16); return 'rgba(' + (n >> 16) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ',' + a + ')'; };
const light = hex => { const n = parseInt(hex.slice(1), 16); const m = v => Math.round(v + (255 - v) * .3); return 'rgb(' + m(n >> 16) + ',' + m((n >> 8) & 255) + ',' + m(n & 255) + ')'; };
function paint(el, c) { el.style.setProperty('--c', c); el.style.setProperty('--c40', tint(c, .4)); el.style.setProperty('--c14', tint(c, .14)); el.style.setProperty('--cl', light(c)); }
$$('[data-c]').forEach(e => paint(e, e.dataset.c));
const KV = rows => rows.map(r => '<div><span>' + r[0] + '</span>' + (r[1] === null || r[1] === undefined ? '<b class="na">N/A</b>' : '<b class="' + (r[2] || '') + '">' + esc(r[1]) + '</b>') + '</div>').join('');
function tween(el, to, fmt) {
  const from = parseFloat(el.dataset.v) || 0; el.dataset.v = to; const t0 = performance.now();
  (function f(t) { const k = Math.min(1, (t - t0) / 650), e = 1 - Math.pow(1 - k, 3); el.textContent = fmt(from + (to - from) * e); if (k < 1) requestAnimationFrame(f); })(t0);
}

/* ripple on every tappable surface */
document.addEventListener('pointerdown', e => {
  const t = e.target.closest && e.target.closest('.fc.tap,.pc,.btn,.mini-btn,.chip,.acc-h'); if (!t) return;
  const r = t.getBoundingClientRect(), s = Math.max(r.width, r.height) * 2;
  const d = document.createElement('span'); d.className = 'rip';
  d.style.cssText = 'width:' + s + 'px;height:' + s + 'px;left:' + (e.clientX - r.left - s / 2) + 'px;top:' + (e.clientY - r.top - s / 2) + 'px';
  t.appendChild(d); setTimeout(() => d.remove(), 650);
}, { passive: true });

/* ---------------------------------------------------------------- toast + logs */
function toast(msg, type) {
  type = type || 'info';
  const el = document.createElement('div');
  el.className = 'toast ' + type;
  const ic = type === 'success' ? 'fa-circle-check' : type === 'error' ? 'fa-circle-exclamation' : 'fa-circle-info';
  el.innerHTML = '<i class="fas ' + ic + '"></i><span></span>';
  el.lastChild.textContent = msg;
  $('#toasts').appendChild(el);
  // errors stay long enough to be read; tap or swipe sideways to dismiss any toast
  const life = type === 'error' ? 6000 : type === 'success' ? 3000 : 4000;
  const close = () => { if (el.dataset.gone) return; el.dataset.gone = 1; el.classList.add('out'); setTimeout(() => el.remove(), 300); };
  const timer = setTimeout(close, life);
  let x0 = null;
  el.addEventListener('click', () => { clearTimeout(timer); close(); });
  el.addEventListener('touchstart', e => { x0 = e.touches[0].clientX; }, { passive: true });
  el.addEventListener('touchmove', e => { if (x0 === null) return; const dx = e.touches[0].clientX - x0; el.style.transform = 'translateX(' + dx + 'px)'; el.style.opacity = String(1 - Math.min(1, Math.abs(dx) / 200)); }, { passive: true });
  el.addEventListener('touchend', e => { if (x0 === null) return; const dx = e.changedTouches[0].clientX - x0; x0 = null; if (Math.abs(dx) > 60) { clearTimeout(timer); close(); } else { el.style.transform = ''; el.style.opacity = ''; } }, { passive: true });
}
window.toast = toast;   // the Android side calls toast() directly
const clock = () => new Date().toLocaleTimeString();

const OPIC = [[/clean/i, 'fa-broom', '#a855f7'], [/cool|thermal|temp/i, 'fa-fan', '#29b6f6'], [/optim|dexopt|recompile|trim|maintenance/i, 'fa-rocket', '#2ed573'],
  [/net/i, 'fa-tower-broadcast', '#ffa502'], [/profile|game|power|multi|auto|reset/i, 'fa-sliders', '#00f5d4'], [/overlay/i, 'fa-window-restore', '#ff4dd2'],
  [/mode|access|shizuku|root/i, 'fa-shield-halved', '#9d4edd'], [/disable|enable|app/i, 'fa-box', '#f5c518']];
function tlItem(e) {
  let ic = 'fa-check', c = '#2ed573';
  if (!e.ok) { ic = 'fa-xmark'; c = '#ff6b81'; } else { for (const o of OPIC) if (o[0].test(e.m)) { ic = o[1]; c = o[2]; break; } }
  const d = document.createElement('div'); d.className = 'tl-item'; paint(d, c);
  d.innerHTML = '<div class="dot"><i class="fas ' + ic + '"></i></div><div class="tx"><b></b><small></small></div>' + (e.ok ? '' : '<span class="st">FAILED</span>');
  $('b', d).textContent = e.m; $('small', d).textContent = fmtAgo(e.t);
  return d;
}
const skel = n => '<div class="skel" aria-hidden="true"><i></i><div><b></b><u></u></div></div>'.repeat(n || 6);
const emptyLog = txt => '<div class="empty-log"><i class="fa-regular fa-clock"></i>' + txt + '</div>';
function log(msg, type) {
  const list = $('#log-list'); const empty = $('.empty-log', list); if (empty) empty.remove();
  list.prepend(tlItem({ m: msg, ok: (type || 'success') !== 'error', t: Date.now() }));
  while (list.children.length > 50) list.lastChild.remove();
}
function term(msg, type) {
  const t = $('#term');
  const d = $('.term-line.dim', t); if (d) d.remove();
  const l = document.createElement('div');
  l.className = 'term-line ' + (type || '');
  l.innerHTML = '<span>&gt;</span><i class="fas ' + (type === 'error' ? 'fa-circle-xmark' : 'fa-circle-check') + '"></i><span></span>';
  l.lastChild.textContent = clock() + ': ' + msg;
  t.appendChild(l); t.scrollTop = t.scrollHeight;
  while (t.children.length > 40) t.firstChild.remove();
}
const report = (ok, msg) => { toast(msg, ok ? 'success' : 'error'); setTimeout(loadLog, 400); };

/* ---------------------------------------------------------------- navigation */
const PAGES = ['home', 'apps', 'quick', 'adv', 'settings', 'about'];
let page = 'home';
function stagger() { $$('#page-' + page + ' > *, #page-' + page + ' [data-widget]').forEach((e, i) => e.style.setProperty('--i', i)); }
function placeIndicator() {
  const b = $('#bnav button.active'), i = $('#nav-ind'); if (!b) return;
  i.style.width = b.offsetWidth + 'px'; i.style.transform = 'translateX(' + b.offsetLeft + 'px)';
}
function go(p) {
  if (p === page) return;
  page = p;
  $$('.page').forEach(x => x.classList.toggle('active', x.id === 'page-' + p));
  $$('#bnav button').forEach(b => b.classList.toggle('active', b.dataset.page === (p === 'about' ? 'settings' : p)));
  stagger(); placeIndicator();
  window.scrollTo({ top: 0, behavior: 'smooth' });
  haptic();
  if (p === 'adv') { refreshToggles(); refreshGov(); refreshOverlay(); }
  if (p === 'quick') { loadLog(); refreshExtra(); refreshCooldown(); }
  if (p === 'apps') loadApps(false);
  if (p === 'settings') { refreshPerms(); loadAiCfg(); }
  if (p === 'home') loadLog();
  if (p !== 'adv' && monTimer) stopMonitor();
}
$$('#bnav button').forEach(b => b.addEventListener('click', () => go(b.dataset.page)));
window.addEventListener('resize', placeIndicator);

/* back button: close sheet/dialog first, then go Home, then let Android exit */
window.kayrootBack = function () {
  const m = $('#modal');
  if (m.classList.contains('show')) { $('#modal-no').hidden ? $('#modal-ok').click() : $('#modal-no').click(); return true; }
  if ($('#onb').classList.contains('show')) { onbClose(); return true; }
  const sh = $$('.overlay.sheet.show'); if (sh.length) { sh.forEach(x => x.classList.remove('show')); return true; }
  if (page === 'about') { go('settings'); return true; }
  if (page !== 'home') { go('home'); return true; }
  return false;
};

/* ---------------------------------------------------------------- state */
let status = { mode: 'basic' };
const rank = () => status.mode === 'root' ? 2 : status.mode === 'shizuku' ? 1 : 0;

function applyStatus(s) {
  status = s || status;
  $$('#mode-seg button').forEach(b => b.classList.toggle('active', b.dataset.mode === status.mode));
  let h;
  if (status.mode === 'basic') {
    if (!status.shizukuInstalled) h = 'Basic mode: only <b>Cleaner</b> &amp; <b>Cooling</b> work. Install <b>Shizuku</b> for profiles, Optimizer &amp; system controls (no root needed).';
    else if (!status.shizukuRunning) h = 'Shizuku is installed but <b>not running</b>. Start it (Wireless debugging), then tap <b>Shizuku</b>.';
    else h = 'Tap <b>Shizuku</b> and allow permission to unlock Pro features.';
  } else if (status.mode === 'shizuku') {
    h = status.shizukuGranted ? 'Shizuku active: profiles, deep cleaner, optimizer &amp; system controls enabled.'
                              : 'Shizuku mode selected but the service is <b>not running</b>. Start Shizuku again.';
  } else h = 'Root active: CPU governors, bypass charging, I/O &amp; kernel tweaks unlocked.';
  $('#access-hint').innerHTML = h;
  $('#device-line').textContent = (status.device || '') + ' | ' + (status.soc || '?') + ' | API ' + (status.sdk || '?');
  setProfileUI(status.profile || '', status.ai);
  lockToggles();
  $('#set-boot').checked = !!status.boot;
  const dbg = $('#set-debug'); if (dbg) dbg.checked = !!status.debug;
}
window.onKayrootStatus = applyStatus;

$$('#mode-seg button').forEach(b => b.addEventListener('click', () => {
  haptic(); log('Switching access mode: ' + b.dataset.mode, 'info');
  native('selectMode', b.dataset.mode);
}));
$('#open-shizuku').addEventListener('click', () => native('openShizuku'));
$('#recent-all').addEventListener('click', () => go('quick'));

/* ---------------------------------------------------------------- profiles */
const PROFILES = [
  { id: 'auto', name: 'Auto AI Mode', desc: 'Adaptive rules engine: reacts to heat, battery & app', icon: 'fa-robot', c: '#f5c518' },
  { id: 'game', name: 'Game Booster', desc: 'Performance mode. More heat and battery use', icon: 'fa-gamepad', c: '#ff3b3b' },
  { id: 'daytoday', name: 'Multitasking', desc: 'Balanced for everyday multitasking', icon: 'fa-list-check', c: '#29b6f6' },
  { id: 'powersave', name: 'Power Saving', desc: 'Power Save: longer battery, slower animations', icon: 'fa-battery-half', c: '#2ed573' }
];
const pl = $('#profile-list');
PROFILES.forEach((p, j) => {
  const d = document.createElement('div');
  d.className = 'pc tap'; d.dataset.id = p.id; d.dataset.desc = p.desc; paint(d, p.c); d.style.setProperty('--j', j);
  d.innerHTML = '<div class="fi"><i class="fas ' + p.icon + '"></i></div><div class="ft"><b>' + p.name + '</b><small>' + p.desc + '</small></div><div class="sel">SELECT</div>';
  d.addEventListener('click', () => selectProfile(p.id));
  pl.appendChild(d);
});
function setProfileUI(id, ai) {
  $$('.pc').forEach(c => {
    const on = c.dataset.id === id; c.classList.toggle('on', on); $('.sel', c).textContent = on ? 'APPLIED' : 'SELECT';
    $('small', c).textContent = (c.dataset.id === 'auto' && on && ai && ai.on && ai.reason) ? 'Running: ' + ai.reason : c.dataset.desc;
  });
  const p = PROFILES.find(x => x.id === id);
  let name = p ? p.name : 'Not selected';
  if (id === 'auto' && ai && ai.profile) name += ' (' + ({ game: 'Game', daytoday: 'Multitasking', powersave: 'Power Saving' }[ai.profile] || ai.profile) + ')';
  $('#cur-profile').textContent = name;
}
async function selectProfile(id) {
  const card = $('.pc[data-id="' + id + '"]');
  if (card.classList.contains('busy')) return;
  haptic(); card.classList.add('busy');
  const r = await call('profile', { name: id });
  card.classList.remove('busy');
  const nm = PROFILES.find(x => x.id === id).name;
  if (r.ok) { setProfileUI(id, null); report(true, nm + ' applied'); }
  else report(false, r.msg || 'Failed');
  refreshStatus();
}
$('#reset-btn').addEventListener('click', async () => {
  haptic(); const r = await call('reset');
  if (r.ok) { setProfileUI('', null); report(true, 'Profiles reset'); } else report(false, r.msg || 'Reset failed');
  refreshStatus();
});

/* ---------------------------------------------------------------- quick page: tiles */
function tile(grid, o) {
  const b = document.createElement('div');
  b.className = 'fc tap'; b.setAttribute('role', 'button'); paint(b, o.c); b.style.setProperty('--j', grid.children.length);
  if (o.id) b.id = o.id;
  b.dataset.def = o.sub;
  b.innerHTML = '<div class="fi"><i class="fas ' + o.icon + '"></i></div><div class="ft"><b>' + o.name + '</b><small class="qs">' + o.sub + '</small></div>' +
    '<div class="fx">' + (o.tag ? '<span class="pill warn">' + o.tag + '</span>' : '') + '<i class="fa-solid fa-chevron-right dim"></i></div>';
  b.addEventListener('click', e => { if (e.target.closest('.qd')) return; o.run(b); }); // clicks inside the expanded panel must not toggle the card
  grid.appendChild(b); return b;
}
/* ---------- KAAM 1 + 2: Quick Actions (always-animated icons + expandable detail) ---------- */
const sleep = ms => new Promise(r => setTimeout(r, ms));
/* live phone readings (RAM %, battery temperature) used for "before -> after" */
async function qSample() {
  const r = await callFast('mon_sample');
  if (!r.ok || !r.data) return null;
  const d = r.data, m = d.ram || {}, bt = d.battery || {};
  return { ram: m.pct == null ? null : Math.round(m.pct), temp: (bt.tempC > 0) ? bt.tempC : null, bat: bt.level == null || bt.level < 0 ? null : bt.level };
}
const fmtT = v => v == null ? 'N/A' : Number(v).toFixed(1) + '°C';
const fmtP = v => v == null ? 'N/A' : v + '%';
/* steps = rows shown in the expanded card. Only things the app really does are listed. */
const QUICK = [
  { id: 'clean', name: 'Cleaner', sub: 'Free RAM, trim caches', icon: 'fa-broom', c: '#a855f7', ok: 'Cleaner finished',
    steps: ['Cache files', 'Temp files (app cache)', 'Background processes'], stats: true },
  { id: 'cool', name: 'Cooling', sub: 'Close heavy apps, cool down', icon: 'fa-fan', c: '#29b6f6', ok: 'Cooling finished',
    steps: ['Background apps closed', 'Battery temperature'], stats: true },
  { id: 'optimize', name: 'Optimizer', sub: 'Tune the system for speed', icon: 'fa-rocket', c: '#2ed573', ok: 'Optimizer started',
    steps: ['Background optimization', 'RAM usage', 'Battery level'], stats: true },
  { id: 'netrefresh', name: 'Net Refresh', sub: 'Reset network connection', icon: 'fa-tower-broadcast', c: '#ffa502', ok: 'Network refreshed' }
];
/* step state: wait / run / done / fail  (icon + progress bar are drawn by CSS) */
function setStep(li, st, val) {
  li.dataset.st = st;
  const ic = li.querySelector('.qs-ic'), v = li.querySelector('.qs-v');
  ic.innerHTML = st === 'done' ? '<i class="fa-solid fa-check"></i>' : st === 'fail' ? '<i class="fa-solid fa-xmark"></i>' : '';
  if (val != null) v.textContent = val;
}
/* build the (initially collapsed) detail panel inside the card */
function buildDetail(q, b) {
  const d = document.createElement('div'); d.className = 'qd';
  d.innerHTML = '<div class="qd-in"><ul class="qsteps">' + q.steps.map(t =>
    '<li class="qstep" data-st="wait"><span class="qs-ic"></span><span class="qs-t">' + t + '</span><span class="qs-v">Waiting</span><span class="qs-bar"><i></i></span></li>').join('') +
    '</ul><button class="btn go wide quick-run"><i class="fa-solid fa-play"></i> Run ' + q.name + '</button><p class="quick-status hint dim">Tap Run to start.</p></div>';
  b.appendChild(d);
  const lis = [...d.querySelectorAll('.qstep')], st = d.querySelector('.quick-status'), btn = d.querySelector('.quick-run');
  btn.addEventListener('click', async ev => {
    ev.stopPropagation(); haptic();
    btn.disabled = true; b.classList.add('busy'); st.textContent = 'Working…';
    lis.forEach(li => setStep(li, 'wait', 'Waiting'));
    const before = q.stats ? await qSample() : null;
    let result = null; const p = call(q.id).then(r => (result = r));
    /* walk the steps one by one; the real action runs in parallel and the last step waits for it */
    for (let i = 0; i < lis.length; i++) {
      setStep(lis[i], 'run', 'Working…');
      if (i < lis.length - 1) await Promise.race([sleep(700), p]); else await p;
      if (result && !result.ok) { setStep(lis[i], 'fail', 'Failed'); break; }
      setStep(lis[i], 'done', 'Done');
    }
    const r = result || { ok: false, msg: 'Failed' };
    if (r.ok) {
      lis.forEach(li => { if (li.dataset.st !== 'done') setStep(li, 'done', 'Done'); });
      /* show real before -> after readings where we have them */
      if (q.stats) {
        await sleep(1200); const after = await qSample();
        if (after && before) {
          if (q.id === 'cool') setStep(lis[1], 'done', fmtT(before.temp) + ' → ' + fmtT(after.temp));
          if (q.id === 'optimize') { setStep(lis[1], 'done', fmtP(before.ram) + ' → ' + fmtP(after.ram)); setStep(lis[2], 'done', fmtP(before.bat) + ' → ' + fmtP(after.bat)); }
          if (q.id === 'clean') st.textContent = 'RAM used: ' + fmtP(before.ram) + ' → ' + fmtP(after.ram);
        }
      }
      if (!(q.id === 'clean' && st.textContent.startsWith('RAM'))) st.textContent = r.msg || q.ok;
    } else st.textContent = r.msg || 'Action failed';
    b.classList.remove('busy'); btn.disabled = false;
    report(r.ok, r.ok ? (r.msg || q.ok) : (r.msg || 'Failed'));
  });
}
QUICK.forEach(q => {
  const hasDetail = !!q.steps;
  const b = tile($('#quick-grid'), { id: 'quick-' + q.id, name: q.name, sub: q.sub, icon: q.icon, c: q.c, run: async b => {
    haptic();
    b.classList.add('fx-on'); setTimeout(() => b.classList.remove('fx-on'), 1600);   /* icon animation plays only after a touch */
    if (hasDetail) {
      /* click = open this card (and close the others); click again = close */
      const open = !b.classList.contains('expanded');
      $$('#quick-grid .fc.expanded').forEach(x => { x.classList.remove('expanded'); x.setAttribute('aria-expanded', 'false'); });
      if (open) { b.classList.add('expanded'); b.setAttribute('aria-expanded', 'true'); }
      return;
    }
    b.classList.add('busy'); const r = await call(q.id); b.classList.remove('busy'); report(r.ok, r.ok ? (r.msg || q.ok) : (r.msg || 'Failed'));
  } });
  if (q.id === 'optimize') $('.fi', b).innerHTML = '<span class="rk"><span class="flame"></span><i class="fas fa-rocket"></i></span>'; /* rocket + fire */
  if (hasDetail) { b.setAttribute('aria-expanded', 'false'); buildDetail(q, b); }
});
$('#clear-log').addEventListener('click', async () => { haptic(); await call('log_clear'); loadLog(); });

/* ---------------------------------------------------------------- system controls (Advance) */
const TOGGLES = [
  { key: 'dnd', c: '#a855f7', icon: 'fa-bell-slash', title: 'Do Not Disturb', on: 'DND is active', off: 'DND is inactive', ic: ['fa-bell-slash', 'fa-bell'], need: 1 },
  { key: 'bypass', c: '#ffa502', icon: 'fa-bolt', title: 'Bypass Charging', on: 'Bypass is active', off: 'Bypass is inactive', ic: ['fa-bolt', 'fa-bolt'], need: 2 },
  { key: 'battery_saver', c: '#2ed573', icon: 'fa-battery-quarter', title: 'Battery Saver', on: 'Battery saver is on', off: 'Battery saver is off', ic: ['fa-leaf', 'fa-leaf'], need: 1 },
  { key: 'hi_refresh', c: '#29b6f6', icon: 'fa-gauge-high', title: 'Max Refresh Rate', on: 'Max refresh locked', off: 'Refresh rate is auto', ic: ['fa-display', 'fa-display'], need: 1 },
  { key: 'fast_anim', c: '#ff4dd2', icon: 'fa-wand-magic-sparkles', title: 'Fast Animations', on: 'Animations 0.5x', off: 'Animations 1x', ic: ['fa-forward-fast', 'fa-forward'], need: 1 },
  { key: 'stay_awake', c: '#f5c518', icon: 'fa-plug-circle-bolt', title: 'Stay Awake (Charging)', on: 'Screen stays on', off: 'Normal screen timeout', ic: ['fa-sun', 'fa-moon'], need: 1 }
];
let tState = {};
const tl = $('#toggle-list');
TOGGLES.forEach((t, j) => {
  const d = document.createElement('div');
  d.className = 'fc'; d.id = 'sys-' + t.key; paint(d, t.c); d.style.setProperty('--j', j);
  d.innerHTML = '<div class="fi"><i class="fas ' + t.icon + '"></i></div><div class="ft"><b>' + t.title + (t.need === 2 ? ' <span class="pill root">ROOT</span>' : '') + '</b><small>--</small></div><label class="switch"><input type="checkbox"><span></span></label>';
  tl.appendChild(d);
  const inp = $('input', d);
  inp.addEventListener('change', async () => {
    const want = inp.checked;
    if (rank() < t.need) { inp.checked = !want; toast(t.need === 2 ? 'Root required for this control' : 'Enable Shizuku or Root first (HOME \u2192 Access Mode)', 'error'); return; }
    haptic(); inp.disabled = true;
    const r = await call('toggle_set', { key: t.key, on: want });
    inp.disabled = false;
    const label = t.title.split(' (')[0].toUpperCase();
    term(r.ok ? label + (want ? ' enabled' : ' disabled') : label + ' failed: ' + (r.msg || 'error'), r.ok ? '' : 'error');
    if (!r.ok) toast(r.msg || 'Failed', 'error');
    refreshToggles();
  });
});
function renderToggle(t) {
  const d = $('#sys-' + t.key); if (!d) return;
  const st = tState[t.key]; const on = !!(st && st.on); const sup = !st || st.supported !== false;
  const locked = rank() < t.need;
  d.classList.toggle('on', on && sup); d.classList.toggle('locked', locked);
  $('.fi i', d).className = 'fas ' + t.ic[on ? 0 : 1];
  $('small', d).textContent = !sup ? 'Not supported on this device' : locked ? (t.need === 2 ? 'Needs Root access' : 'Needs Shizuku or Root') : (on ? t.on : t.off);
  const inp = $('input', d); inp.checked = on; inp.disabled = !sup;
}
const lockToggles = () => TOGGLES.forEach(renderToggle);
async function refreshToggles() {
  const r = await callFast('toggle_get_all');
  if (r && r.data) { tState = r.data; lockToggles(); }
}
setInterval(() => { if (!document.hidden && page === 'adv') refreshToggles(); }, 6000);

async function refreshGov() {
  const hint = $('#gov-hint'), chips = $('#gov-chips');
  if (rank() < 2) { hint.textContent = 'Needs Root access'; chips.innerHTML = ''; return; }
  const r = await call('gov_info');
  if (!r.ok || !r.data) { hint.textContent = r.msg || 'Governor info unavailable'; chips.innerHTML = ''; return; }
  hint.textContent = 'Current: ' + r.data.current;
  chips.innerHTML = '';
  (r.data.available || []).forEach(g => {
    const c = document.createElement('button');
    c.className = 'chip' + (g === r.data.current ? ' on' : ''); c.textContent = g;
    c.addEventListener('click', async () => {
      haptic(); const x = await call('gov_set', { name: g });
      term(x.ok ? 'GOVERNOR set to ' + g : 'GOVERNOR failed: ' + (x.msg || 'error'), x.ok ? '' : 'error');
      refreshGov();
    });
    chips.appendChild(c);
  });
}

/* ---------------------------------------------------------------- settings */
const THEMES = [['#00f5d4', '#9d4edd', 'CYBER', '#00796b'], ['#ff4dd2', '#7b2cff', 'NEON', '#b3158f'], ['#39ff14', '#00b4d8', 'MATRIX', '#2a7a0c'], ['#ffb300', '#ff3b3b', 'SOLAR', '#a85a00']];
const th = $('#themes');
let isLight = false;
function resolveLight() { const m = store.get('colormode', 'dark'); return m === 'light' || (m === 'auto' && !!(window.matchMedia && matchMedia('(prefers-color-scheme: light)').matches)); }
function applyTheme(i) {
  const t = THEMES[i] || THEMES[0];
  isLight = resolveLight();
  document.documentElement.dataset.theme = isLight ? 'light' : 'dark';
  document.documentElement.style.setProperty('--accent', isLight ? t[3] : t[0]);   // darker accent keeps contrast on white
  document.documentElement.style.setProperty('--accent2', t[1]);
  $$('.tdot').forEach((d, k) => d.classList.toggle('on', k === i));
  $$('#mode-chips .chip').forEach(c => { c.classList.toggle('on', c.dataset.k === store.get('colormode', 'dark')); c.setAttribute('aria-checked', c.classList.contains('on')); });
  if (typeof drawGraph === 'function') try { drawGraph(); } catch (e) {}
}
[['dark', 'Dark'], ['light', 'Light'], ['auto', 'Auto (system)']].forEach(([k, t]) => {
  const c = document.createElement('button'); c.className = 'chip'; c.textContent = t; c.dataset.k = k; c.setAttribute('role', 'radio');
  c.addEventListener('click', () => { store.set('colormode', k); applyTheme(store.get('theme', 0)); haptic(); }); $('#mode-chips').appendChild(c);
});
if (window.matchMedia) { try { matchMedia('(prefers-color-scheme: light)').addEventListener('change', () => { if (store.get('colormode', 'dark') === 'auto') applyTheme(store.get('theme', 0)); }); } catch (e) {} }
THEMES.forEach((t, i) => {
  const d = document.createElement('button'); d.className = 'tdot'; d.textContent = t[2];
  d.style.setProperty('--tc', t[0]); d.style.setProperty('--tc2', t[1]);
  d.addEventListener('click', () => { store.set('theme', i); applyTheme(i); haptic(); });
  th.appendChild(d);
});
applyTheme(store.get('theme', 0));
$('#set-rain').checked = store.get('rain', false);
$('#set-haptic').checked = store.get('haptic', true);
$('#set-rain').addEventListener('change', e => { store.set('rain', e.target.checked); rainOn = e.target.checked; $('#rain').style.display = rainOn ? '' : 'none'; });
$('#set-haptic').addEventListener('change', e => store.set('haptic', e.target.checked));
$('#set-boot').addEventListener('change', async e => {
  const r = await call('boot_set', { on: e.target.checked });
  if (!r.ok) { e.target.checked = !e.target.checked; toast(r.msg || 'Failed', 'error'); }
});

function modal(title, html, okText, cancelText) {
  return new Promise(res => {
    const m = $('#modal'), ok = $('#modal-ok'), no = $('#modal-no');
    $('#modal-title').textContent = title; $('#modal-body').innerHTML = html;
    ok.textContent = okText || 'OK'; no.textContent = cancelText || 'Cancel'; no.hidden = cancelText === null;
    const done = v => { m.classList.remove('show'); ok.onclick = no.onclick = null; res(v); };
    ok.onclick = () => done(true); no.onclick = () => done(false);
    m.classList.add('show');
  });
}

/* ---------- customizable home dashboard ---------- */
function applyHomeLayout() {
  const root = $('#home-widgets'); if (!root) return;
  const order = store.get('homeOrder', ['profiles', 'recent']);
  order.forEach(id => { const el = root.querySelector('[data-widget="' + id + '"]'); if (el) root.appendChild(el); });
  const showProfiles = store.get('homeShowProfiles', true), showRecent = store.get('homeShowRecent', true);
  $('#profiles-widget').hidden = !showProfiles; $('#profiles-heading').hidden = !showProfiles;
  $('#recent-card').hidden = !showRecent;
  const size = store.get('homeWidgetSize', 'normal'); root.classList.remove('widgets-compact', 'widgets-large');
  if (size === 'compact') root.classList.add('widgets-compact');
  if (size === 'large') root.classList.add('widgets-large');
}
$('#home-customize').addEventListener('click', async () => {
  const showProfiles = store.get('homeShowProfiles', true), showRecent = store.get('homeShowRecent', true);
  const order = store.get('homeOrder', ['profiles', 'recent']).join('-'); const size = store.get('homeWidgetSize', 'normal');
  const html = '<label class="home-pref"><input id="home-show-profiles" type="checkbox" ' + (showProfiles ? 'checked' : '') + '> Show profile widget</label>' +
    '<label class="home-pref"><input id="home-show-recent" type="checkbox" ' + (showRecent ? 'checked' : '') + '> Show recent operations</label>' +
    '<p class="label">Widget order</p><select id="home-order" class="wide-input"><option value="profiles-recent" ' + (order === 'profiles-recent' ? 'selected' : '') + '>Profiles → Recent operations</option><option value="recent-profiles" ' + (order === 'recent-profiles' ? 'selected' : '') + '>Recent operations → Profiles</option></select>' +
    '<p class="label">Widget size</p><select id="home-size" class="wide-input"><option value="compact" ' + (size === 'compact' ? 'selected' : '') + '>Compact</option><option value="normal" ' + (size === 'normal' ? 'selected' : '') + '>Normal</option><option value="large" ' + (size === 'large' ? 'selected' : '') + '>Large</option></select>';
  if (!await modal('Customize dashboard', html, 'Apply')) return;
  const ps = $('#home-show-profiles'), rs = $('#home-show-recent'), os = $('#home-order'), ss = $('#home-size');
  store.set('homeShowProfiles', !!(ps && ps.checked)); store.set('homeShowRecent', !!(rs && rs.checked));
  store.set('homeOrder', (os && os.value === 'recent-profiles') ? ['recent', 'profiles'] : ['profiles', 'recent']);
  store.set('homeWidgetSize', ss ? ss.value : 'normal'); applyHomeLayout();
});
setTimeout(applyHomeLayout, 0);

/* ---------- history (persisted natively) ---------- */
async function loadLog() {
  const r = await callFast('log_get'); if (!r.ok || !r.data) return;
  const list = $('#log-list'); list.innerHTML = '';
  if (!r.data.length) list.innerHTML = emptyLog('No activity yet');
  r.data.forEach(e => list.appendChild(tlItem(e)));
  const hr = $('#home-recent');
  hr.innerHTML = r.data.length ? '' : emptyLog('No operations yet');
  r.data.slice(0, 4).forEach(e => hr.appendChild(tlItem(e)));
  $('#recent-sub').textContent = r.data.length ? r.data.length + ' operations logged' : 'Latest actions on this device';
}
$('#hist-clear').addEventListener('click', async () => { haptic(); await call('log_clear'); loadLog(); toast('History cleared', 'success'); });
$('#set-debug').addEventListener('change', e => call('debug_set', { on: e.target.checked }));

/* ---------------------------------------------------------------- monitor page */
$$('.acc').forEach(a => {
  paint(a, a.dataset.c);
  $('.acc-h', a).addEventListener('click', () => { a.classList.toggle('open'); haptic(); });
});

/* ---------------------------------------------------------------- LIVE MONITOR (redesigned) */
let monTimer = null, monInt = 2000, monBusy = false;
const histC = [], histR = [], MAXP = 30;           /* last 30 samples of CPU % and RAM % */
const MON_INTS = [[1000, '1s'], [2000, '2s'], [5000, '5s']];
MON_INTS.forEach(([v, t]) => { const c = document.createElement('button'); c.className = 'chip' + (v === monInt ? ' on' : ''); c.textContent = t; c.dataset.v = v;
  c.addEventListener('click', () => { monInt = v; $$('#mon-int .chip').forEach(x => x.classList.toggle('on', +x.dataset.v === v)); if (monTimer) { stopMonitor(); startMonitor(); } haptic(); }); $('#mon-int').appendChild(c); });

const accentCol = () => getComputedStyle(document.documentElement).getPropertyValue('--accent').trim() || '#00f5d4';
const loadCol = p => p > 85 ? '#ff4d6d' : p > 60 ? '#ffa502' : accentCol();
/* gauge: pathLength=100 on the circles, so offset = 100 - percent (CSS animates it smoothly) */
function setRing(id, pct) { $(id).style.strokeDashoffset = pct == null ? 100 : 100 - Math.max(0, Math.min(100, pct)); }
/* one tile: value text, sub text, progress bar + colour */
function setTile(id, pct, val, sub, col) {
  const t = $(id); if (!t) return; const bar = $('.mt-bar i', t), v = $('.mt-v', t);
  t.style.setProperty('--tc', pct == null ? 'rgba(220,240,255,.4)' : (col || loadCol(pct)));
  bar.style.transform = 'scaleX(' + (pct == null ? 0 : Math.max(0.02, Math.min(100, pct) / 100)) + ')';
  if (typeof val === 'number') tween(v, val, x => x.toFixed(0) + '%'); else { v.dataset.v = 0; v.textContent = val; }
  $('.mt-s', t).textContent = sub;
}
/* smooth line graph: CPU (accent) + RAM (purple), new sample slides in */
let gSlide = 1, gRaf = 0;
function drawGraph(slide) {
  const c = $('#cpu-graph'); if (!c) return; const w = c.clientWidth; if (!w) return;
  const dpr = Math.min(window.devicePixelRatio || 1, 2), H = 96; if (c.width !== Math.round(w * dpr)) { c.width = Math.round(w * dpr); c.height = H * dpr; }
  const x = c.getContext('2d'); x.setTransform(dpr, 0, 0, dpr, 0, 0); x.clearRect(0, 0, w, H);
  x.strokeStyle = isLight ? 'rgba(12,20,40,.10)' : 'rgba(255,255,255,.07)'; x.lineWidth = 1; x.beginPath(); [24, 48, 72].forEach(y => { x.moveTo(0, y); x.lineTo(w, y); }); x.stroke();
  const n = Math.max(histC.length, histR.length);
  if (n < 2) { x.fillStyle = isLight ? 'rgba(12,20,40,.55)' : 'rgba(220,245,255,.6)'; x.font = '11px system-ui'; x.fillText(monTimer ? 'collecting samples…' : 'Press Start for a live graph', 12, 52); return; }
  const step = w / (MAXP - 1), off = w - (n - 1) * step + (1 - (slide == null ? 1 : slide)) * step;
  const Y = v => H - 8 - v * (H - 18) / 100;
  const line = (arr, col, fill) => {
    const pts = []; arr.forEach((v, i) => { if (v != null) pts.push({ x: off + (i + (n - arr.length)) * step, y: Y(v) }); });
    if (pts.length < 2) return;
    x.beginPath(); x.moveTo(pts[0].x, pts[0].y);
    for (let i = 1; i < pts.length - 1; i++) x.quadraticCurveTo(pts[i].x, pts[i].y, (pts[i].x + pts[i + 1].x) / 2, (pts[i].y + pts[i + 1].y) / 2);
    const l = pts[pts.length - 1]; x.lineTo(l.x, l.y);
    x.strokeStyle = col; x.lineWidth = 2.2; x.lineJoin = 'round'; x.stroke();
    if (fill) { x.lineTo(l.x, H); x.lineTo(pts[0].x, H); x.closePath(); const g = x.createLinearGradient(0, 0, 0, H); g.addColorStop(0, col + '55'); g.addColorStop(1, col + '00'); x.fillStyle = g; x.fill(); }
    x.beginPath(); x.arc(l.x, l.y, 3.6, 0, 7); x.fillStyle = col; x.fill();               /* glowing dot on the newest value */
    x.beginPath(); x.arc(l.x, l.y, 7, 0, 7); x.fillStyle = col + '30'; x.fill();
  };
  line(histR, '#9d4edd', false); line(histC, accentCol(), true);
}
function slideIn() {                                   /* 450 ms slide of the newest sample (only runs after each sample) */
  cancelAnimationFrame(gRaf); const t0 = performance.now();
  (function f(t) { const k = Math.min(1, (t - t0) / 450); drawGraph(1 - Math.pow(1 - k, 3)); if (k < 1) gRaf = requestAnimationFrame(f); })(t0);
}
function setLive(on) {
  const p = $('#mon-live'); p.classList.toggle('on', on); $('span', p).textContent = on ? 'LIVE' : 'IDLE';
  $('#mon-ring').classList.toggle('live', on);
}
async function monTick() {
  if (monBusy || document.hidden) return; monBusy = true;
  const r = await callFast('mon_sample'); monBusy = false;
  if (!r.ok || !r.data) return; const d = r.data, b = d.battery || {}, m = d.ram || {};
  const ramPct = m.totalMb ? m.usedMb * 100 / m.totalMb : null;
  histC.push(d.cpuPct === null || d.cpuPct === undefined ? null : d.cpuPct); histR.push(ramPct); if (histC.length > MAXP) histC.shift(); if (histR.length > MAXP) histR.shift();
  const mx = d.freqMhz && d.freqMhz.length ? Math.max.apply(null, d.freqMhz) : null;
  /* gauge: outer = CPU, inner = RAM. Centre shows CPU (or RAM when CPU is not available) */
  const hasCpu = d.cpuPct !== null && d.cpuPct !== undefined, main = hasCpu ? d.cpuPct : ramPct;
  setRing('#g-cpu', hasCpu ? d.cpuPct : null); setRing('#g-ram', ramPct);
  $('#mon-ring').style.setProperty('--rc', main == null ? 'rgba(220,240,255,.45)' : loadCol(main));
  if (main == null) { $('#g-val').textContent = 'N/A'; $('#g-val').dataset.v = 0; } else tween($('#g-val'), main, v => v.toFixed(0) + '%');
  $('#g-lbl').textContent = hasCpu ? 'CPU' : 'RAM';
  /* tiles */
  setTile('#mt-cpu', hasCpu ? d.cpuPct : null, hasCpu ? d.cpuPct : 'N/A', d.cores + ' cores' + (mx ? ' • ' + mx + ' MHz' : ''));
  const hasGpu = d.gpuPct !== null && d.gpuPct !== undefined;
  setTile('#mt-gpu', hasGpu ? d.gpuPct : null, hasGpu ? d.gpuPct : 'N/A', d.gpuMhz ? Math.round(d.gpuMhz) + ' MHz' : (d.mode === 'basic' ? 'needs Shizuku/Root' : 'not exposed by this chip'));
  setTile('#mt-ram', ramPct, ramPct == null ? 'N/A' : ramPct, m.totalMb ? (m.usedMb / 1024).toFixed(1) + ' / ' + (m.totalMb / 1024).toFixed(1) + ' GB' + (m.pressure ? ' • ' + m.pressure : '') : '--');
  const tC = d.cpuTemp != null ? d.cpuTemp : (b.tempC != null && b.tempC > 0 ? b.tempC : null);
  const tPct = tC == null ? null : Math.max(0, Math.min(100, (tC - 20) * 100 / 40));
  setTile('#mt-temp', tPct, tC == null ? 'N/A' : tC.toFixed(1) + '\u00b0C', (d.cpuTemp != null ? 'CPU' : 'Battery') + (d.thermal && d.thermal !== 'N/A' ? ' • ' + (d.thermal === 'None' ? 'Normal' : d.thermal) : ''), tC == null ? null : (tC > 45 ? '#ff4d6d' : tC > 38 ? '#ffa502' : '#2ed573'));
  $('#mon-note').textContent = d.sampleOk === false ? ('Monitor command failed: ' + (d.sampleError || 'access unavailable') + '. Check selected access mode and permissions.') : (!hasCpu && d.mode === 'basic' ? 'CPU/GPU usage needs Shizuku or Root: Android blocks it for normal apps.' : 'Updating every ' + (monInt / 1000) + ' s. FPS is in the overlay below.');
  slideIn();
}
function startMonitor() { monTick(); monTimer = setInterval(monTick, monInt); $('#mon-toggle').innerHTML = '<i class="fa-solid fa-stop"></i> Stop'; setLive(true); }
function stopMonitor() { clearInterval(monTimer); monTimer = null; const t = $('#mon-toggle'); if (t) t.innerHTML = '<i class="fa-solid fa-play"></i> Start'; setLive(false); }
/* opening the Advance tab starts the monitor by itself; leaving it stops it (saves battery) */
function autoStartMonitor() { if (page === 'adv' && !monTimer && !document.hidden) { histC.length = 0; histR.length = 0; call('mon_reset'); startMonitor(); } }
$('#mon-toggle').addEventListener('click', () => { haptic(); if (monTimer) stopMonitor(); else { histC.length = 0; histR.length = 0; call('mon_reset'); startMonitor(); } });
document.addEventListener('visibilitychange', () => { if (document.hidden && monTimer) stopMonitor(); });
setTimeout(() => drawGraph(1), 300);
window.addEventListener('resize', () => drawGraph(1));

/* ---------- overlay ---------- */
const OV = [['fps', 'FPS'], ['cpu', 'CPU'], ['gpu', 'GPU'], ['ram', 'RAM'], ['bat', 'Battery'], ['temp', 'Temp'], ['pwr', 'Power']];
let ovCfg = { stats: 'fps,cpu,ram,bat,temp', running: false };
OV.forEach(([k, t]) => { const c = document.createElement('button'); c.className = 'chip'; c.textContent = t; c.dataset.k = k;
  c.addEventListener('click', () => { const set = new Set(ovCfg.stats.split(',').filter(Boolean)); set.has(k) ? set.delete(k) : set.add(k); ovCfg.stats = [...set].join(','); paintOv(); call('overlay_cfg_set', { stats: ovCfg.stats }); haptic(); }); $('#ov-stats').appendChild(c); });
function paintOv() {
  const on = new Set(ovCfg.stats.split(',').filter(Boolean)); $$('#ov-stats .chip').forEach(c => c.classList.toggle('on', on.has(c.dataset.k)));
  $('#ov-toggle').innerHTML = ovCfg.running ? '<i class="fa-solid fa-stop"></i> Stop overlay' : '<i class="fa-solid fa-play"></i> Start overlay';
  $('#ov-alpha-v').textContent = $('#ov-alpha').value + '%'; $('#ov-size-v').textContent = $('#ov-size').value + ' sp'; $('#ov-int-v').textContent = ($('#ov-int').value / 1000).toFixed(2) + ' s';
  $('#acc-ov .fs').textContent = ovCfg.running ? 'Running \u2022 ' + on.size + ' stats shown' : 'Off \u2022 tap to configure';
  $('#acc-ov').classList.toggle('on', !!ovCfg.running);
}
async function refreshOverlay() {
  const r = await callFast('overlay_cfg_get'); if (!r.ok || !r.data) return; ovCfg = r.data;
  $('#ov-alpha').value = ovCfg.alpha; $('#ov-size').value = ovCfg.size; $('#ov-int').value = ovCfg.interval; paintOv();
}
[['#ov-alpha', 'alpha'], ['#ov-size', 'size'], ['#ov-int', 'interval']].forEach(([sel, key]) => { const el = $(sel); el.addEventListener('input', paintOv); el.addEventListener('change', () => call('overlay_cfg_set', { [key]: +el.value })); });
$('#ov-toggle').addEventListener('click', async () => {
  haptic();
  if (ovCfg.running) { const r = await call('overlay_stop'); report(r.ok, r.msg || 'Stopped'); }
  else {
    const r = await call('overlay_start');
    if (r.perm) { const g = await modal('Permission needed', 'The overlay draws on top of other apps, so Android asks you to allow <b>Display over other apps</b> for Kayroot. Nothing else is accessed.', 'Open settings'); if (g) native('openSystem', 'overlay'); }
    else report(r.ok, r.msg || 'Failed');
  }
  setTimeout(refreshOverlay, 600);
});

/* ---------------------------------------------------------------- apps (with real icons) */
const iconCache = new Map(), iconWant = new Set(); let iconBusy = false, iconTimer = null;
const hash = s => { let h = 0; for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0; return h; };
function attachImg(d, src) { const im = new Image(); im.alt = ''; im.onload = () => im.classList.add('ld'); im.src = src; d.appendChild(im); }
function fillAvatar(d, name, pkg) {
  const hue = hash(pkg) % 360;
  d.dataset.p = pkg; d.style.setProperty('--c', 'hsl(' + hue + ',72%,64%)'); d.style.setProperty('--c2', 'hsl(' + ((hue + 55) % 360) + ',72%,46%)');
  d.textContent = (name || '?').trim().charAt(0).toUpperCase();
  const c = iconCache.get(pkg); if (c) attachImg(d, c);
}
const iconTry = new Map();
async function flushIcons() {
  if (iconBusy) { iconTimer = setTimeout(flushIcons, 120); return; }
  const batch = [...iconWant].slice(0, 12); if (!batch.length) return; batch.forEach(p => iconWant.delete(p));
  iconBusy = true; const r = await callFast('app_icons', { pkgs: batch }); iconBusy = false;
  if (!r || !r.ok) {   // bridge busy/timeout: retry a few times instead of caching "no icon" forever
    batch.forEach(p => { const n = (iconTry.get(p) || 0) + 1; iconTry.set(p, n); if (n < 4) iconWant.add(p); else iconCache.set(p, ''); });
    if (iconWant.size) iconTimer = setTimeout(flushIcons, 1500); return;
  }
  const got = r.data || {};
  batch.forEach(p => { iconCache.set(p, got[p] || ''); if (got[p]) $$('.ai[data-p="' + p + '"]').forEach(el => { if (!$('img', el)) attachImg(el, got[p]); }); });
  if (iconWant.size) iconTimer = setTimeout(flushIcons, 30);
}
function wantIcon(p) { if (iconCache.has(p)) return; iconWant.add(p); clearTimeout(iconTimer); iconTimer = setTimeout(flushIcons, 40); }
const io = 'IntersectionObserver' in window ? new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { io.unobserve(e.target); wantIcon(e.target.dataset.p); } }), { rootMargin: '400px' }) : null;
function avatar(name, pkg) { const d = document.createElement('div'); d.className = 'ai'; fillAvatar(d, name, pkg); if (io) io.observe(d); else wantIcon(pkg); return d; }

let appsAll = [], appsLoaded = false, appFilter = 'user', excl = new Set(), games = new Set();
const AFILTERS = [['user', 'User'], ['system', 'System'], ['disabled', 'Disabled'], ['all', 'All'], ['excl', 'Excluded']];
AFILTERS.forEach(([k, t]) => { const c = document.createElement('button'); c.className = 'chip' + (k === appFilter ? ' on' : ''); c.textContent = t; c.dataset.k = k;
  c.addEventListener('click', () => { appFilter = k; $$('#app-filter .chip').forEach(x => x.classList.toggle('on', x.dataset.k === k)); renderApps(); haptic(); }); $('#app-filter').appendChild(c); });
$$('#app-tabs button').forEach(b => b.addEventListener('click', () => {
  $$('#app-tabs button').forEach(x => x.classList.toggle('active', x === b));
  $('#app-tabs').classList.toggle('second', b.dataset.tab === 'debloat');
  $('#tab-manage').hidden = b.dataset.tab !== 'manage'; $('#tab-debloat').hidden = b.dataset.tab !== 'debloat';
  if (b.dataset.tab === 'debloat') loadDebloat(); haptic();
}));
async function loadExcl() { const r = await callFast('excl_get'); if (r.ok && r.data) excl = new Set(r.data); }
async function loadApps(force) {
  if (appsLoaded && !force) return;
  $('#app-count').textContent = 'Loading apps...';
  if (!appsAll.length) $('#app-list').innerHTML = skel(7);
  const r = await callFast('apps_list'); if (!r.ok || !r.data) { $('#app-count').textContent = r.msg || 'Failed to load apps'; return; }
  appsAll = r.data; appsLoaded = true; renderApps();
}
$('#app-q').addEventListener('input', () => renderApps());
function renderApps() {
  const q = $('#app-q').value.trim().toLowerCase();
  let l = appsAll.filter(a => (appFilter === 'all') || (appFilter === 'user' && !a.s) || (appFilter === 'system' && a.s) || (appFilter === 'disabled' && !a.e) || (appFilter === 'excl' && excl.has(a.p)));
  if (q) l = l.filter(a => a.n.toLowerCase().includes(q) || a.p.toLowerCase().includes(q));
  l.sort((a, b) => a.n.localeCompare(b.n));
  $('#app-count').textContent = l.length + ' apps' + (l.length > 150 ? ' (showing first 150, use search)' : '');
  const box = $('#app-list'); box.innerHTML = '';
  if (!l.length) { box.innerHTML = emptyLog('No apps match'); return; }
  const frag = document.createDocumentFragment();
  l.slice(0, 150).forEach(a => {
    const d = document.createElement('div'); d.className = 'arow';
    d.innerHTML = '<div class="at"><b></b><small></small></div><div class="tags"></div>';
    d.insertBefore(avatar(a.n, a.p), d.firstChild);
    $('b', d).textContent = a.n; $('small', d).textContent = a.p;
    $('.tags', d).innerHTML = (a.s ? '<span class="pill">SYS</span>' : '') + (a.e ? '' : '<span class="pill bad">OFF</span>') + (a.l ? '<span class="pill shizuku">LOCK</span>' : '') + (excl.has(a.p) ? '<span class="pill good">EXCL</span>' : '');
    d.addEventListener('click', () => openApp(a)); frag.appendChild(d);
  });
  box.appendChild(frag);
}
async function openApp(a) {
  haptic(); const sh = $('#sheet'); $('#sheet-title').textContent = a.n; $('#sheet-body').textContent = 'Loading...'; $('#sheet-actions').innerHTML = '';
  const av = $('#sheet-ai'); av.innerHTML = ''; fillAvatar(av, a.n, a.p); if (!iconCache.has(a.p)) wantIcon(a.p);
  sh.classList.add('show');
  const r = await callFast('app_details', { pkg: a.p }); if (!r.ok) { $('#sheet-body').textContent = r.msg || 'Failed'; return; } const d = r.data;
  $('#sheet-body').innerHTML = '<div class="kv">' + KV([['Package', d.p], ['Version', d.ver], ['Type', d.sys ? 'System app' : 'User app'], ['State', d.enabled ? 'Enabled' : 'Disabled', d.enabled ? 'good' : 'bad'], ['Size (APK)', d.sizeMb + ' MB'], ['Installer', d.installer || 'unknown']]) + '</div>' + (d.lock ? '<p class="hint warn">Protected package: it cannot be disabled or uninstalled from here.</p>' : '');
  const acts = $('#sheet-actions');
  const add = (label, icon, fn, dis) => { const b = document.createElement('button'); b.className = 'btn'; b.innerHTML = '<i class="fa-solid ' + icon + '"></i> ' + label; b.disabled = !!dis; b.addEventListener('click', fn); acts.appendChild(b); };
  add('Launch', 'fa-play', async () => { const x = await call('app_launch', { pkg: d.p }); if (!x.ok) toast(x.msg, 'error'); }, !d.launch);
  add('App settings', 'fa-gear', () => call('app_settings', { pkg: d.p }));
  add(excl.has(d.p) ? 'Remove exclusion' : 'Exclude from cleaner', 'fa-shield', async () => { excl.has(d.p) ? excl.delete(d.p) : excl.add(d.p); await call('excl_set', { list: [...excl] }); toast('Exclusion list updated', 'success'); $('#sheet').classList.remove('show'); renderApps(); });
  add(games.has(d.p) ? 'Remove game mark' : 'Mark as game', 'fa-gamepad', async () => { games.has(d.p) ? games.delete(d.p) : games.add(d.p); await call('games_set', { list: [...games] }); toast(games.has(d.p) ? 'Added: Auto AI will use Game Booster for it' : 'Game mark removed', 'success'); $('#sheet').classList.remove('show'); renderAiGames(); });
  add('Set Auto AI profile', 'fa-sliders', async () => {
    const pr = await callFast('app_profiles_get'); const map = pr.ok && pr.data ? pr.data : {};
    const current = map[d.p] || '';
    const html = '<p>Choose the profile Auto AI should use for this app. Thermal protection and low-battery saving still take priority.</p><select id="app-profile-choice" class="wide-input" aria-label="Per-app profile"><option value="">Use automatic rules</option><option value="game">Game Booster</option><option value="daytoday">Multitasking</option><option value="powersave">Power Saving</option></select>';
    if (!await modal('Per-app Auto AI profile', html, 'Save')) return;
    const select = $('#app-profile-choice'); const profile = select ? select.value : current;
    const x = await call('app_profile_set', { pkg: d.p, profile }); report(x.ok, x.msg || 'Profile not saved');
  });
  if (!d.sys) add('Uninstall', 'fa-trash', async () => { if (await modal('Uninstall ' + d.n + '?', 'Android will ask you to confirm. App data will be lost.', 'Continue')) { const x = await call('app_uninstall', { pkg: d.p }); toast(x.msg || (x.ok ? 'Opened' : 'Failed'), x.ok ? 'info' : 'error'); } }, d.lock);
  add(d.enabled ? 'Disable' : 'Enable', d.enabled ? 'fa-ban' : 'fa-circle-check', async () => {
    if (rank() < 1) return toast('Enable Shizuku or Root first (HOME \u2192 Access Mode)', 'error');
    if (!await modal((d.enabled ? 'Disable ' : 'Enable ') + d.n + '?', d.enabled ? 'The app will stop running and disappear from the launcher. You can re-enable it here at any time.' : 'The app will be re-enabled.', 'Confirm')) return;
    const x = await call('debloat_apply', { action: d.enabled ? 'disable' : 'enable', pkgs: [d.p] }); const row = x.data && x.data[0];
    report(!!(row && row.ok), row ? d.n + ': ' + row.msg : 'Failed'); $('#sheet').classList.remove('show'); loadApps(true); debloatLoaded = false;
  }, d.lock && d.enabled);
}
$('#sheet-close').addEventListener('click', () => $('#sheet').classList.remove('show'));
$('#sheet').addEventListener('click', e => { if (e.target.id === 'sheet') $('#sheet').classList.remove('show'); });

/* ---------- apps: debloat ---------- */
let debloatLoaded = false, dlist = []; const picked = new Set();
async function loadDebloat() {
  if (debloatLoaded) return; const box = $('#debloat-list'); box.innerHTML = skel(6);
  const r = await callFast('debloat_list'); if (!r.ok) { box.innerHTML = emptyLog(esc(r.msg || 'Failed')); return; }
  dlist = r.data; debloatLoaded = true; picked.clear(); renderDebloat();
}
function renderDebloat() {
  const box = $('#debloat-list'); box.innerHTML = ''; if (!dlist.length) { box.innerHTML = emptyLog('None of the known candidates are installed here.'); $('#debloat-n').textContent = 0; return; }
  [['review', 'SAFE TO REVIEW'], ['critical', 'CRITICAL / PROTECTED (locked)']].forEach(([tier, title]) => {
    const items = dlist.filter(x => x.tier === tier); if (!items.length) return;
    const h = document.createElement('div'); h.className = 'dgroup'; h.textContent = title; box.appendChild(h);
    items.forEach(x => {
      const d = document.createElement('label'); d.className = 'drow' + (x.lock ? ' lock' : '');
      d.innerHTML = '<div class="at"><b></b> <span class="pill"></span><small class="why"></small><small class="pk"></small></div><input type="checkbox">';
      d.insertBefore(avatar(x.l, x.p), d.firstChild);
      const cb = $('input', d); cb.disabled = x.lock; cb.checked = picked.has(x.p);
      $('b', d).textContent = x.l; $('.pill', d).textContent = x.e ? x.cat : 'DISABLED'; if (!x.e) $('.pill', d).classList.add('bad');
      $('.why', d).textContent = x.why; $('.pk', d).textContent = x.p;
      cb.addEventListener('change', () => { cb.checked ? picked.add(x.p) : picked.delete(x.p); $('#debloat-n').textContent = picked.size; haptic(); });
      box.appendChild(d);
    });
  });
  $('#debloat-n').textContent = picked.size;
}
$('#debloat-preview').addEventListener('click', async () => {
  if (!picked.size) return toast('Select at least one app', 'info');
  if (rank() < 1) return toast('Enable Shizuku or Root first (HOME \u2192 Access Mode)', 'error');
  const plan = [...picked].map(p => dlist.find(x => x.p === p)).filter(Boolean);
  const dis = plan.filter(x => x.e), en = plan.filter(x => !x.e);
  const li = a => '<ul>' + a.map(x => '<li><b>' + esc(x.l) + '</b><br><small>' + esc(x.p) + '</small></li>').join('') + '</ul>';
  const html = (dis.length ? '<b>Will be disabled (reversible):</b>' + li(dis) : '') + (en.length ? '<b>Will be re-enabled:</b>' + li(en) : '') + '<p class="hint warn" style="text-align:left">To undo later: select the same app here, or open it in MANAGE and tap Enable.</p>';
  if (!await modal('Planned actions', html, 'Execute')) return;
  haptic(); let lines = [];
  for (const [action, arr] of [['disable', dis], ['enable', en]]) {
    if (!arr.length) continue; const r = await call('debloat_apply', { action, pkgs: arr.map(x => x.p) });
    (r.data || []).forEach(x => lines.push((x.ok ? '\u2705 ' : '\u274C ') + esc(x.p) + ' \u2014 ' + esc(x.msg)));
  }
  await modal('Result', '<pre>' + lines.join('\n') + '</pre>', 'Done', null);
  debloatLoaded = false; appsLoaded = false; loadDebloat(); setTimeout(loadLog, 300);
});

/* ---------------------------------------------------------------- quick: deep optimization / safety tiles */
const EXTRA = [
  { id: 'bgdexopt', name: 'Dexopt', sub: 'Android\'s own app optimization job', icon: 'fa-gears', c: '#2ed573' },
  { id: 'speedprofile', name: 'Recompile', sub: 'Profile-guided recompile of all apps', icon: 'fa-microchip', c: '#ff4dd2' },
  { id: 'fstrim', name: 'Trim storage', sub: 'Discard unused filesystem blocks', icon: 'fa-hard-drive', c: '#ffa502' }
];
EXTRA.forEach(x => tile($('#extra-grid'), { id: 'x-' + x.id, name: x.name, sub: x.sub, icon: x.icon, c: x.c, tag: 'HEAVY', run: async b => {
  if (rank() < 1) return toast('Enable Shizuku or Root first (HOME \u2192 Access Mode)', 'error');
  haptic(); b.classList.add('busy'); let r = await call('extra_run', { kind: x.id });
  if (r.confirm) { b.classList.remove('busy'); if (!await modal('Run again?', esc(r.msg), 'Run anyway')) return; b.classList.add('busy'); r = await call('extra_run', { kind: x.id, force: true }); }
  b.classList.remove('busy'); report(r.ok, r.msg || 'Failed'); refreshExtra();
} }));
tile($('#tool-grid'), { id: 't-cd', name: 'Cooldown', sub: 'Emergency cool-down steps', icon: 'fa-temperature-arrow-down', c: '#29b6f6', run: () => { haptic(); refreshCooldown(); $('#cd-sheet').classList.add('show'); } });
tile($('#tool-grid'), { name: 'View log', sub: 'Recent warnings & errors', icon: 'fa-file-lines', c: '#a855f7', run: async () => { haptic(); const r = await call('log_view'); await modal('Recent warnings & errors', '<pre>' + esc(r.data || r.msg || 'No output') + '</pre>', 'Close', null); } });
tile($('#tool-grid'), { name: 'Clear logcat', sub: 'Empty debug log buffers', icon: 'fa-eraser', c: '#ff6b81', run: async () => {
  if (!await modal('Clear logcat buffers?', 'This empties the on-device debug log buffers. Android security/audit logs are not touched, and nothing else is deleted.', 'Clear')) return;
  const r = await call('logcat_clear'); report(r.ok, r.msg || 'Failed');
} });

async function refreshExtra() {
  for (const x of EXTRA) {
    if (x.id === 'fstrim') continue;
    const r = await callFast('extra_status', { kind: x.id }); const s = $('#x-' + x.id + ' .qs'); if (!s || !r.ok) continue;
    s.textContent = r.state === 'running' ? 'Running for ' + (r.last ? Math.max(1, Math.round((Date.now() - r.last) / 60000)) + ' min' : 'a while') + '... (Android gives no progress %)' : r.state.startsWith('done:0') ? 'Last run finished OK' : r.state.startsWith('done:') ? 'Last run ended with code ' + r.state.slice(5) : (r.last ? 'Last started ' + fmtAgo(r.last) : $('#x-' + x.id).dataset.def);
  }
  const t = await callFast('extra_sched_get'); if (t.ok) { $('#extra-sched').checked = !!t.on; $('#extra-last').textContent = 'Last background dexopt: ' + fmtAgo(t.lastRun) + '. Android picks the time (charging + idle).'; }
  if ($$('#extra-grid .qs').some(e => e.textContent.startsWith('Running'))) setTimeout(() => { if (page === 'quick') refreshExtra(); }, 15000);
}
$('#extra-sched').addEventListener('change', async e => { const r = await call('extra_sched', { on: e.target.checked }); if (!r.ok) e.target.checked = !e.target.checked; report(r.ok, r.msg || 'Failed'); });
$('#extra-reset').addEventListener('click', async () => { haptic(); const r = await call('reset'); if (r.ok) setProfileUI('', null); report(r.ok, r.ok ? 'Optimization settings reset' : (r.msg || 'Reset failed')); });

/* cooldown sheet */
const cdSheet = $('#cd-sheet');
$('#cd-close').addEventListener('click', () => cdSheet.classList.remove('show'));
cdSheet.addEventListener('click', e => { if (e.target === cdSheet) cdSheet.classList.remove('show'); });
$('#cd-run').addEventListener('click', async () => {
  const steps = $$('[data-cd]').filter(i => i.checked).map(i => i.dataset.cd); if (!steps.length) return toast('Pick at least one step', 'info');
  const risky = steps.includes('airplane');
  cdSheet.classList.remove('show');
  const ok = await modal('Emergency cooldown', '<ul>' + steps.map(s => '<li>' + ({ overlay: 'Stop the stats overlay', ai: 'Stop the Auto AI loop', bgkill: 'Close background apps', battsaver: 'Turn battery saver on', airplane: '<b>Airplane mode ON</b>' }[s]) + '</li>').join('') + '</ul>' +
    (risky ? '<p class="hint warn" style="text-align:left"><b>Airplane mode will cut calls, mobile data, Wi-Fi and notifications</b> until restored.</p>' : '') + '<p>Temporary changes are restored after 10 minutes or when you tap Restore.</p>', 'Cool down');
  if (!ok) return; haptic(); const r = await call('cooldown', { steps }); report(r.ok, r.msg || 'Failed'); refreshCooldown();
});
$('#cd-restore').addEventListener('click', async () => { cdSheet.classList.remove('show'); const r = await call('cooldown_restore'); report(r.ok, r.msg || 'Failed'); refreshCooldown(); });
async function refreshCooldown() {
  const r = await callFast('cooldown_get'); const act = !!(r.ok && r.data && r.data.length);
  $('#cd-restore').hidden = !act;
  const t = $('#t-cd'); let tg = $('.live-pill', t);
  if (act && !tg) { tg = document.createElement('span'); tg.className = 'pill good live-pill'; tg.textContent = 'ACTIVE'; $('.fx', t).prepend(tg); } else if (!act && tg) tg.remove();
}

/* ---------- settings: permissions + capability scan ---------- */
const PERM_ACT = { overlay: () => native('openSystem', 'overlay'), notif: () => native('openSystem', 'notif'), battery: () => native('openSystem', 'battery'), shizuku: () => native('openShizuku'), root: () => native('selectMode', 'root') };
async function refreshPerms() {
  const r = await callFast('perm_status'); if (!r.ok || !r.data) return; const box = $('#perm-list'); box.innerHTML = '';
  r.data.forEach(p => { const d = document.createElement('div'); d.className = 'crow'; paint(d, p.ok ? '#2ed573' : '#ffa502');
    d.innerHTML = '<div class="ci"><i class="fas ' + (p.ok ? 'fa-check' : 'fa-exclamation') + '"></i></div><div class="ft"><b></b><small></small></div><span class="pill ' + (p.ok ? 'good' : 'warn') + '">' + (p.ok ? 'GRANTED' : 'NOT GRANTED') + '</span>';
    $('b', d).textContent = p.name; $('small', d).textContent = p.why;
    if (!p.ok) { const b = document.createElement('button'); b.className = 'mini-btn'; b.textContent = p.id === 'root' ? 'Check root' : p.id === 'shizuku' ? 'Open Shizuku' : 'Open settings'; b.addEventListener('click', PERM_ACT[p.id]); $('.ft', d).appendChild(b); }
    box.appendChild(d); });
}
const ST = { supported: 'SUPPORTED', partial: 'PARTIAL', permission: 'PERMISSION REQUIRED', shizuku: 'SHIZUKU REQUIRED', root: 'ROOT REQUIRED', unsupported: 'KERNEL/DEVICE UNSUPPORTED', failed: 'FAILED', untested: 'NOT TESTED' };
const STC = { supported: '#2ed573', partial: '#ffa502', permission: '#ffa502', untested: '#ffa502', shizuku: '#9d4edd', root: '#9d4edd', unsupported: '#ff6b81', failed: '#ff6b81' };
$('#caps-scan').addEventListener('click', async () => {
  haptic(); $('#caps-list').innerHTML = skel(5); const b = $('#caps-scan'); b.disabled = true; b.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Scanning...';
  const r = await call('caps_scan'); b.disabled = false; b.innerHTML = '<i class="fa-solid fa-magnifying-glass-chart"></i> Run scan';
  if (!r.ok || !r.data) { $('#caps-list').innerHTML = ''; return toast(r.msg || 'Scan failed', 'error'); }
  const box = $('#caps-list'); box.innerHTML = '';
  r.data.forEach(c => { const d = document.createElement('div'); d.className = 'crow'; paint(d, STC[c.status] || '#9d4edd');
    d.innerHTML = '<div class="ci"><i class="fas ' + (c.status === 'supported' ? 'fa-check' : c.status === 'failed' || c.status === 'unsupported' ? 'fa-xmark' : 'fa-minus') + '"></i></div><div class="ft"><b></b><small></small></div><span class="pill ' + c.status + '">' + ST[c.status] + '</span>';
    $('b', d).textContent = c.name; $('small', d).textContent = c.detail; box.appendChild(d); });
});

/* ---------------------------------------------------------------- matrix rain */
if (!store.get('perf2', 0)) { store.set('perf2', 1); store.set('rain', false); }   /* one-time: matrix rain off by default (it made the app laggy) */
let rainOn = store.get('rain', false);
(function rain() {
  const c = $('#rain'), x = c.getContext('2d'); let cols, drops;
  function size() { c.width = innerWidth; c.height = innerHeight; cols = Math.floor(c.width / 14); drops = Array.from({ length: cols }, () => Math.random() * -50); }
  size(); addEventListener('resize', size);
  if (!rainOn) c.style.display = 'none';
  let rcol = '#0f8'; setInterval(() => { rcol = getComputedStyle(document.documentElement).getPropertyValue('--accent').trim() || '#0f8'; }, 4000);
  setInterval(() => {
    if (!rainOn || document.hidden || isLight) return;
    x.fillStyle = 'rgba(4,5,13,.12)'; x.fillRect(0, 0, c.width, c.height);
    x.fillStyle = rcol; x.font = '13px monospace';
    for (let i = 0; i < cols; i++) {
      x.fillText(Math.random() > .5 ? '1' : '0', i * 14, drops[i] * 14);
      if (drops[i] * 14 > c.height && Math.random() > .975) drops[i] = 0;
      drops[i]++;
    }
  }, 90);
})();


/* ---------------------------------------------------------------- Auto AI rules (settings) */
let aiCfg = { nightOn: false, nightFrom: 23, nightTo: 6, noGameWhileCharging: false, lowBattery: 20, minSwitchSec: 60, rules: [] };
const hourLabel = h => String(h).padStart(2, '0') + ':00';
[['#ai-from', 23], ['#ai-to', 6]].forEach(([sel]) => { for (let h = 0; h < 24; h++) { const o = document.createElement('option'); o.value = h; o.textContent = hourLabel(h); $(sel).appendChild(o); } });
[[0, 'No delay'], [30, '30 seconds'], [60, '1 minute'], [120, '2 minutes'], [300, '5 minutes']].forEach(([v, t]) => { const o = document.createElement('option'); o.value = v; o.textContent = t; $('#ai-cool').appendChild(o); });
function renderAiGames() {
  const box = $('#ai-games'); box.innerHTML = '';
  if (!games.size) { box.innerHTML = '<span class="rule-empty">No games added yet. Built-in detection still works.</span>'; return; }
  [...games].forEach(p => { const c = document.createElement('button'); c.className = 'chip on'; c.textContent = p + '  ✕'; c.setAttribute('aria-label', 'Remove ' + p);
    c.addEventListener('click', async () => { games.delete(p); await call('games_set', { list: [...games] }); renderAiGames(); }); box.appendChild(c); });
}
function renderAiRules() {
  const box = $('#ai-rules'); box.innerHTML = '';
  if (!aiCfg.rules.length) { box.innerHTML = '<div class="rule-empty">No custom rules. Example: IF temperature &gt; 40 THEN Power Saving.</div>'; return; }
  aiCfg.rules.forEach((r, i) => {
    const d = document.createElement('div'); d.className = 'rule-row';
    d.innerHTML = '<span>IF</span><select aria-label="Metric"><option value="temp">Temperature &deg;C</option><option value="battery">Battery %</option></select>' +
      '<select aria-label="Comparison"><option value=">">above</option><option value="<">below</option></select>' +
      '<input type="number" inputmode="decimal" aria-label="Value"><span>THEN</span>' +
      '<select aria-label="Profile"><option value="powersave">Power Saving</option><option value="daytoday">Multitasking</option><option value="game">Game Booster</option></select>' +
      '<button class="mini-btn danger" aria-label="Delete rule"><i class="fa-regular fa-trash-can"></i></button>';
    const [m, o, p] = $$('select', d), v = $('input', d);
    m.value = r.metric; o.value = r.op; v.value = r.value; p.value = r.profile;
    m.onchange = () => { r.metric = m.value; }; o.onchange = () => { r.op = o.value; }; p.onchange = () => { r.profile = p.value; };
    v.oninput = () => { const n = parseFloat(v.value); if (!isNaN(n)) r.value = n; };
    $('.mini-btn', d).onclick = () => { aiCfg.rules.splice(i, 1); renderAiRules(); };
    box.appendChild(d);
  });
}
function paintAiCfg() {
  $('#ai-night').checked = !!aiCfg.nightOn; $('#ai-from').value = aiCfg.nightFrom; $('#ai-to').value = aiCfg.nightTo;
  $('#ai-nogame').checked = !!aiCfg.noGameWhileCharging; $('#ai-cool').value = String(aiCfg.minSwitchSec);
  $('#ai-low').value = aiCfg.lowBattery; $('#ai-low-v').textContent = aiCfg.lowBattery + '%';
  renderAiRules();
}
async function loadAiCfg() {
  const r = await callFast('ai_cfg_get'); if (!r.ok || !r.data) return;
  aiCfg = Object.assign(aiCfg, r.data.cfg || {}); aiCfg.rules = (r.data.cfg && r.data.cfg.rules) || [];
  games = new Set(r.data.games || []); paintAiCfg(); renderAiGames();
}
$('#ai-low').addEventListener('input', () => { $('#ai-low-v').textContent = $('#ai-low').value + '%'; });
$('#ai-add').addEventListener('click', () => { if (aiCfg.rules.length >= 10) return toast('Maximum 10 rules', 'info'); aiCfg.rules.push({ metric: 'temp', op: '>', value: 40, profile: 'powersave' }); renderAiRules(); haptic(); });
$('#ai-save').addEventListener('click', async () => {
  haptic();
  aiCfg.nightOn = $('#ai-night').checked; aiCfg.nightFrom = +$('#ai-from').value; aiCfg.nightTo = +$('#ai-to').value;
  aiCfg.noGameWhileCharging = $('#ai-nogame').checked; aiCfg.minSwitchSec = +$('#ai-cool').value; aiCfg.lowBattery = +$('#ai-low').value;
  const r = await call('ai_cfg_set', { cfg: aiCfg }); report(r.ok, r.msg || 'Saved'); loadAiCfg();
});

/* ---------------------------------------------------------------- backup / restore / crash log */
const UI_KEYS = ['theme', 'colormode', 'rain', 'haptic', 'onb'];
$('#bk-export').addEventListener('click', async () => {
  haptic(); const ui = {}; UI_KEYS.forEach(k => { const v = store.get(k, null); if (v !== null) ui[k] = v; });
  const r = await call('backup_export', { ui }); if (!r.ok || !r.data) return toast(r.msg || 'Export failed', 'error');
  native('shareText', 'Kayroot Engine backup', r.data); toast('Choose where to save the backup (Drive, Files, Telegram...)', 'info');
});
$('#bk-import').addEventListener('click', async () => {
  haptic();
  const ok = await modal('Restore settings', '<p>Paste the backup text you exported earlier.</p><textarea class="bk" id="bk-text" placeholder="{ &quot;format&quot;: &quot;kayroot-backup&quot; ... }" aria-label="Backup text"></textarea><button class="btn wide" id="bk-paste"><i class="fa-regular fa-clipboard"></i> Paste from clipboard</button>', 'Restore');
  if (!ok) return;
  const text = ($('#bk-text') || {}).value || ''; if (!text.trim()) return toast('Nothing to restore', 'info');
  const r = await call('backup_import', { text }); if (!r.ok) return report(false, r.msg || 'Restore failed');
  const ui = r.ui || {}; UI_KEYS.forEach(k => { if (k in ui) store.set(k, ui[k]); });
  applyTheme(store.get('theme', 0)); rainOn = store.get('rain', false); $('#rain').style.display = rainOn ? '' : 'none';
  $('#set-rain').checked = rainOn; $('#set-haptic').checked = store.get('haptic', true);
  loadExcl(); loadAiCfg(); refreshStatus(); report(true, r.msg || 'Restored');
});
document.addEventListener('click', e => { if (e.target.closest && e.target.closest('#bk-paste')) { const t = native('readClipboard') || ''; const ta = $('#bk-text'); if (ta) { ta.value = t; if (!t) toast('Clipboard is empty', 'info'); } } });
$('#crash-open').addEventListener('click', async () => {
  haptic(); const r = await call('crash_get'); const txt = r.data || '';
  if (!txt) return toast('No crashes recorded. Good news!', 'success');
  const share = await modal('Crash log', '<pre>' + esc(txt) + '</pre><p class="hint dim" style="text-align:left">Stored only on this phone. Nothing was sent anywhere.</p><button class="btn wide danger-btn" id="crash-clear"><i class="fa-regular fa-trash-can"></i> Clear log</button>', 'Share', 'Close');
  if (share) native('shareText', 'Kayroot Engine crash log', txt);
});
document.addEventListener('click', async e => { if (e.target.closest && e.target.closest('#crash-clear')) { await call('crash_clear'); $('#modal-no').click(); toast('Crash log cleared', 'success'); } });

/* ---------------------------------------------------------------- onboarding (first run + from Settings) */
const ONB = [
  { ic: 'fa-shield-halved', c: '#00f5d4', t: 'Welcome to Kayroot Engine', x: 'Boost, clean and monitor your phone. Everything runs on your device, no account and no analytics.' },
  { ic: 'fa-key', c: '#9d4edd', t: 'What is Access Mode?', x: '<b>Basic</b>: no setup, only Cleaner and Cooling.<br><b>Shizuku</b>: unlocks profiles, Optimizer and system controls with no root (install the Shizuku app and start it with Wireless debugging).<br><b>Root</b>: everything, including CPU governors.' },
  { ic: 'fa-robot', c: '#f5c518', t: 'Try Auto AI Mode', x: 'On HOME pick <b>Auto AI Mode</b> and the app switches between Game, Multitasking and Power Saving for you. Customise it in <b>Settings &rarr; Auto AI rules</b>.' }
];
let onbI = 0;
function onbShow() {
  const o = ONB[onbI]; paint($('#onb-ic'), o.c);
  $('#onb-ic').innerHTML = '<i class="fas ' + o.ic + '"></i>'; $('#onb-title').textContent = o.t; $('#onb-text').innerHTML = o.x;
  $('#onb-dots').innerHTML = ONB.map((_, k) => '<span class="' + (k === onbI ? 'on' : '') + '"></span>').join('');
  $('#onb-next').textContent = onbI === ONB.length - 1 ? 'Get started' : 'Next';
}
function onbOpen() { onbI = 0; onbShow(); $('#onb').classList.add('show'); }
function onbClose() { $('#onb').classList.remove('show'); store.set('onb', 1); }
$('#onb-next').addEventListener('click', () => { haptic(); if (onbI >= ONB.length - 1) onbClose(); else { onbI++; onbShow(); } });
$('#onb-skip').addEventListener('click', onbClose);
$('#intro-open').addEventListener('click', onbOpen);

/* ---------------------------------------------------------------- pull to refresh */
(function () {
  const ptr = $('#ptr'); let y0 = null, dy = 0, busy = false;
  const refreshers = {
    home: () => { refreshStatus(); loadLog(); loadExcl(); },
    quick: () => { loadLog(); refreshExtra(); refreshCooldown(); },
    apps: () => loadApps(true),
    adv: () => { refreshToggles(); refreshGov(); refreshOverlay(); },
    settings: () => { refreshPerms(); loadAiCfg(); }
  };
  document.addEventListener('touchstart', e => {
    if (busy || window.scrollY > 0 || $('.overlay.show') || e.target.closest('input,textarea,select,.term,#log-list,.chips.scroll,canvas')) { y0 = null; return; }
    y0 = e.touches[0].clientY; dy = 0;
  }, { passive: true });
  document.addEventListener('touchmove', e => {
    if (y0 === null) return; dy = e.touches[0].clientY - y0;
    if (dy <= 0) { ptr.classList.remove('pull'); return; }
    const k = Math.min(dy, 110); ptr.classList.add('pull'); ptr.style.transform = 'translateY(' + (k * .8 - 40 + 12) + 'px)';
    $('i', ptr).style.transform = 'rotate(' + (k * 3) + 'deg)';
  }, { passive: true });
  document.addEventListener('touchend', () => {
    if (y0 === null) return; const fire = dy > 80; y0 = null;
    if (!fire) { ptr.classList.remove('pull'); ptr.style.transform = ''; return; }
    busy = true; ptr.classList.add('go'); ptr.style.transform = 'translateY(56px)'; haptic();
    try { (refreshers[page] || (() => {}))(); } catch (e) {}
    setTimeout(() => { ptr.classList.remove('go', 'pull'); ptr.style.transform = ''; busy = false; toast('Refreshed', 'success'); }, 900);
  }, { passive: true });
})();

/* ---------------------------------------------------------------- accessibility: roles, labels, keyboard */
function enhanceA11y() {
  $$('.tap,.acc-h,.pc').forEach(e => { if (!e.hasAttribute('role')) e.setAttribute('role', 'button'); if (!e.hasAttribute('tabindex')) e.tabIndex = 0; });
  $$('.acc').forEach(a => { const h = $('.acc-h', a); if (h) h.setAttribute('aria-expanded', a.classList.contains('open')); });
  $$('.pc').forEach(c => c.setAttribute('aria-pressed', c.classList.contains('on')));
  $$('.switch input:not([aria-label])').forEach(i => { const b = i.closest('.fc,.fc.sm'); const t = b && $('.ft b', b); if (t) i.setAttribute('aria-label', t.textContent.replace(/\s+/g, ' ').trim()); });
  $$('.chips .chip').forEach(c => { if (!c.hasAttribute('role')) c.setAttribute('aria-pressed', c.classList.contains('on')); });
  $$('#bnav button').forEach(b => b.setAttribute('aria-current', b.classList.contains('active') ? 'page' : 'false'));
  $$('.fc.locked input').forEach(i => i.setAttribute('aria-disabled', 'true'));
  $$('.bigring').forEach(e => e.setAttribute('role', 'img'));
  const r = $('#mon-ring'); if (r) r.setAttribute('aria-label', 'CPU usage ' + $('.bv b', r).textContent);
  $$('.ai').forEach(e => e.setAttribute('aria-hidden', 'true'));
}
let a11yQ = 0;
new MutationObserver(() => { if (a11yQ) return; a11yQ = setTimeout(() => { a11yQ = 0; enhanceA11y(); }, 250); })
  .observe(document.body, { subtree: true, childList: true, attributes: true, attributeFilter: ['class'] });
document.addEventListener('keydown', e => {
  if ((e.key === 'Enter' || e.key === ' ') && e.target && e.target.matches && e.target.matches('[role=button]:not(button)')) { e.preventDefault(); e.target.click(); }
});
enhanceA11y();

/* ---------------------------------------------------------------- boot */
async function refreshStatus() {
  const raw = native('getStatus'); if (raw) { try { applyStatus(JSON.parse(raw)); } catch (e) {} }
}
setInterval(() => { if (!document.hidden && page === 'home') refreshStatus(); }, 4000);
window.addEventListener('load', () => {
  stagger(); refreshStatus(); placeIndicator(); loadLog(); loadExcl(); loadAiCfg();
  setTimeout(() => { $('#loading').classList.add('hide'); placeIndicator(); if (!store.get('onb', 0)) onbOpen(); }, 900);
});
if (document.fonts && document.fonts.ready) document.fonts.ready.then(placeIndicator);

/* ---------------------------------------------------------------- mock (browser preview only) */
function installMock() {
  const s = { mode: 'shizuku', shizukuInstalled: true, shizukuRunning: true, shizukuGranted: true, sdk: 34, device: 'Preview Phone', soc: 'Snapdragon', profile: 'auto', ai: { on: true, profile: 'daytoday', reason: 'Battery 62%, temp 36 C' }, boot: false };
  const t = { dnd: { on: false }, bypass: { on: true, supported: true }, battery_saver: { on: false }, hi_refresh: { on: true }, fast_anim: { on: false }, stay_awake: { on: false } };
  const apps = ['Chrome:com.android.chrome', 'WhatsApp:com.whatsapp', 'Instagram:com.instagram.android', 'YouTube:com.google.android.youtube', 'Telegram:org.telegram.messenger', 'Spotify:com.spotify.music'];
  const svg = (l, h) => 'data:image/svg+xml;utf8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 96 96"><rect width="96" height="96" fill="hsl(' + h + ',70%,45%)"/><circle cx="48" cy="48" r="26" fill="white" opacity=".85"/><text x="48" y="58" font-size="30" text-anchor="middle" fill="hsl(' + h + ',70%,35%)" font-family="sans-serif">' + l + '</text></svg>');
  window.KayrootApp = {
    getStatus: () => JSON.stringify(s),
    getStats: () => JSON.stringify({ battery: { level: 62, temp: 36.4, charging: false, voltage: 4012 }, ram: { usedMb: 4210, totalMb: 7600, pct: 55 }, storage: { freeGb: 88.2, totalGb: 256, pct: 66 } }),
    selectMode: m => { s.mode = m; window.onKayrootStatus(s); },
    openShizuku() {}, haptic() {}, openSystem() {}, shareText() {}, readClipboard: () => '',
    fastCall: (a, args, cb) => setTimeout(() => {
      let r = { ok: true, msg: '' };
      if (a === 'mon_sample') r.data = { cores: 8, sampleOk: true, sampleError: '', cpuPct: 20 + Math.random() * 40, freqMhz: [1800, 2400, 2800], gpuPct: null, gpuMhz: null, cpuTemp: 41.2, thermal: 'None', ram: { totalMb: 7600, availMb: 3300, usedMb: 4300, pct: 56, cachedMb: 2100, swapTotalMb: 2048, swapFreeMb: 1900, pressure: 'Normal' }, battery: { level: 62, tempC: 36.4 }, mode: 'shizuku' };
      else if (a === 'perf_history_get') r.data = window.__krMockHistory || [];
      else if (a === 'perf_compare') r.data = { baselineTs: Date.now() - 60000, currentTs: Date.now(), baseline: {}, current: {}, delta: {} };
      else if (a === 'perf_baseline_save') r.data = {};
      else if (a === 'battery_history_get') r.data = window.__krMockBatteryHistory || [];
      else if (a === 'app_profiles_get') r.data = window.__krMockProfiles || {};
      else if (a === 'batt_info') r.data = { level: 62, voltageMv: 4012, tempC: 36.4, status: 'Discharging', plugged: 'No', health: 'Good', currentMa: -420, powerW: 1.7, chargeNowMah: 2900, estFullMah: 4680, cycles: null, battOptIgnored: false };
      else if (a === 'overlay_cfg_get') r.data = { running: false, perm: true, stats: 'fps,cpu,ram,bat,temp', alpha: 80, size: 12, interval: 1500 };
      else if (a === 'log_get') r.data = [];
      else if (a === 'ai_cfg_get') r.data = { cfg: { nightOn: false, nightFrom: 23, nightTo: 6, noGameWhileCharging: false, lowBattery: 20, minSwitchSec: 60, rules: [{ metric: 'temp', op: '>', value: 40, profile: 'powersave' }] }, games: [] };
      else if (a === 'perm_status') r.data = [{ id: 'overlay', name: 'Display over other apps', why: 'Overlay only', ok: false }, { id: 'shizuku', name: 'Shizuku', why: 'Unlocks pro features', ok: true }];
      else if (a === 'cooldown_get' || a === 'excl_get') r.data = [];
      else if (a === 'extra_status') { r.state = ''; r.last = 0; }
      else if (a === 'extra_sched_get') { r.on = false; r.lastRun = 0; }
      else if (a === 'app_icons') { r.data = {}; JSON.parse(args).pkgs.forEach(p => { const i = apps.findIndex(x => x.split(':')[1] === p); if (i >= 0) r.data[p] = svg(apps[i][0], i * 55); }); }
      window[cb](r);
    }, 200),
    call: (a, args, cb) => setTimeout(() => {
      const A = JSON.parse(args); let r = { ok: true, msg: '' };
      if (a === 'toggle_get_all') r.data = t;
      else if (a === 'crash_get') r.data = '';
      else if (a === 'backup_export') r.data = JSON.stringify({ format: 'kayroot-backup', version: 1, prefs: {}, ui: {} }, null, 2);
      else if (a === 'toggle_set') { t[A.key].on = A.on; }
      else if (a === 'gov_info') r.data = { current: 'schedutil', available: ['performance', 'schedutil', 'powersave', 'conservative'] };
      else if (a === 'profile') s.profile = A.name;
      else if (a === 'perf_history_clear') window.__krMockHistory = [];
      else if (a === 'battery_history_clear') window.__krMockBatteryHistory = [];
      else if (a === 'app_profile_set') { window.__krMockProfiles = window.__krMockProfiles || {}; if (A.profile) window.__krMockProfiles[A.pkg] = A.profile; else delete window.__krMockProfiles[A.pkg]; }
      else if (a === 'apps_list') r.data = apps.map(x => ({ n: x.split(':')[0], p: x.split(':')[1], s: false, e: true, l: false })).concat([{ n: 'Facebook Services', p: 'com.facebook.services', s: true, e: true, l: false }, { n: 'Calculator', p: 'com.android.calculator2', s: true, e: false, l: false }]);
      else if (a === 'app_details') r.data = { p: A.pkg, n: A.pkg, ver: '1.0 (1)', sys: false, enabled: true, sizeMb: 42.1, installer: 'com.android.vending', lock: false, launch: true };
      else if (a === 'debloat_list') r.data = [{ p: 'com.facebook.services', l: 'Facebook Services', cat: 'Preinstalled', why: 'Support service for the Facebook app.', tier: 'review', e: true, lock: false }, { p: 'com.google.android.gms', l: 'Google Play services', cat: 'Critical', why: 'Do not disable.', tier: 'critical', e: true, lock: true }];
      window[cb](r);
    }, 400)
  };
}

/* ---------- KAAM 5: About page (opened from Settings) ---------- */
/* >>> Edit these values to change what the About page shows <<< */
const ABOUT = {
  version: 'v2.4',
  developer: 'Kayroot',
  email: 'support@yourdomain.com' /* TODO: put your real support email here */
};
$('#about-ver').textContent = 'Version ' + ABOUT.version + ' • Android App';
$('#about-dev').textContent = 'Developer: ' + ABOUT.developer;
$('#about-mail-t').textContent = ABOUT.email;
$('#about-mail').setAttribute('href', 'mailto:' + ABOUT.email + '?subject=' + encodeURIComponent('Kayroot Engine support'));
$('#open-about').addEventListener('click', () => go('about'));
$('#about-back').addEventListener('click', () => go('settings'));
$('#about-privacy').addEventListener('click', () => { haptic(); modal('Privacy Policy',
  '<p><b>Everything runs on your device.</b> The app needs no account and sends no analytics or crash reports. The optional crash log stays on your phone until you share it.</p><p>Privileged actions run only after you pick Shizuku or Root and tap a control.</p>', 'Close', null); });
$('#about-terms').addEventListener('click', () => { haptic(); modal('Terms of Use',
  '<p>Kayroot Engine changes system settings on your phone. Use it at your own risk.</p><p>Features depend on your device, Android version and access mode (Basic / Shizuku / Root). Results are not guaranteed, and the app is provided "as is" without warranty.</p>', 'Close', null); });

/* ---------- swipe-down to close bottom sheets (app details + Cooldown) ---------- */
(function sheetSwipe() {
  $$('.overlay.sheet').forEach(ov => {
    const dlg = $('.dialog', ov); let y0 = null, dy = 0, drag = false, t0 = 0;
    const reset = () => { dlg.style.transition = ''; dlg.style.transform = ''; dlg.style.animation = ''; ov.style.background = ''; };
    dlg.addEventListener('touchstart', e => {
      if (e.touches.length !== 1) { y0 = null; return; }
      /* start a drag only from the top of the sheet (or from the grip/title), so normal scrolling still works */
      if (dlg.scrollTop > 0 && !e.target.closest('.sheet-grip,.sheet-head')) { y0 = null; return; }
      y0 = e.touches[0].clientY; dy = 0; drag = false; t0 = Date.now();
    }, { passive: true });
    dlg.addEventListener('touchmove', e => {
      if (y0 === null) return;
      dy = e.touches[0].clientY - y0;
      if (!drag) { if (dy < 3) return; drag = true; dlg.style.animation = 'none'; dlg.style.transition = 'none'; }
      if (e.cancelable) e.preventDefault();
      const k = Math.max(0, dy); dlg.style.transform = 'translateY(' + k + 'px)';
      ov.style.background = 'rgba(0,0,0,' + (0.68 * (1 - Math.min(k / 420, 1))).toFixed(2) + ')';
    }, { passive: false });
    const end = () => {
      if (y0 === null) return; y0 = null; if (!drag) return; drag = false;
      const fast = dy / Math.max(1, Date.now() - t0) > 0.6;
      dlg.style.transition = 'transform .25s ease';
      if (dy > 110 || fast) {            /* swiped far/fast enough: slide away and close */
        dlg.style.transform = 'translateY(100%)'; haptic();
        setTimeout(() => { ov.classList.remove('show'); reset(); }, 230);
      } else { dlg.style.transform = 'translateY(0)'; setTimeout(reset, 260); }  /* otherwise snap back */
    };
    dlg.addEventListener('touchend', end); dlg.addEventListener('touchcancel', end);
  });
})();
})(); /* end of main app block (About + swipe code above now live inside it) */
