head -n1 /proc/stat 2>/dev/null
echo '--freq'
for f in /sys/devices/system/cpu/cpu[0-9]*/cpufreq/scaling_cur_freq; do [ -r "$f" ] && cat "$f" 2>/dev/null; done
echo '--gpu'
for p in /sys/class/kgsl/kgsl-3d0/gpu_busy_percentage /sys/class/kgsl/kgsl-3d0/devfreq/cur_freq /sys/class/devfreq/*gpu*/cur_freq /sys/class/devfreq/*mali*/cur_freq; do
  [ -r "$p" ] && echo "$p $(cat "$p" 2>/dev/null)"
done
echo '--temp'
for z in /sys/class/thermal/thermal_zone*; do
  t=$(cat "$z/type" 2>/dev/null); v=$(cat "$z/temp" 2>/dev/null)
  [ -n "$v" ] && echo "$t $v"
done
