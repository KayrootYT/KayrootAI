# Conservative cleaner (root). Does not erase crash diagnostics, user downloads, photos, or documents.
# Skips apps on the user's exclusion list and Kayroot itself ($EXCL comes from the app).
sync
n=0
for d in /data/user/*/*/cache /data/user_de/*/*/cache; do
  [ -d "$d" ] || continue
  pkg=${d%/cache}; pkg=${pkg##*/}
  case "$EXCL" in *" $pkg "*) continue;; esac
  find "$d" -mindepth 1 -maxdepth 1 -exec rm -rf {} + 2>/dev/null
  n=$((n + 1))
done
echo "ok: app caches cleaned for $n apps (excluded apps skipped); diagnostic logs and user files preserved"
