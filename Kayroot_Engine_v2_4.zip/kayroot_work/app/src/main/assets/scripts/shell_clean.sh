# Conservative Shizuku cleaner: ask Android to trim app caches. Never deletes Downloads, photos or documents.
# "pm trim-caches N" only frees caches until N bytes are free, so ask for (free space + 2 GB) or it does nothing on a phone with plenty of space.
set -- $(df -k /data 2>/dev/null | tail -n 1)
if [ "$#" -ge 6 ]; then AVAIL=$4; else AVAIL=$3; fi
case "$AVAIL" in ''|*[!0-9]*) AVAIL=0;; esac
ok pm trim-caches $((AVAIL + 2097152))K
echo "info: user files and diagnostic logs were preserved"
