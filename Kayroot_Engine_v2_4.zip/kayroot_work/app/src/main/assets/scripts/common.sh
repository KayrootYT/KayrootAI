# Kayroot Engine - shared helpers (runs in Android sh/mksh)
# ok CMD...  : run a command quietly, print "ok: CMD" when it succeeded
ok() { "$@" >/dev/null 2>&1 && echo "ok: $*"; return 0; }

# w FILE VALUE : write to a sysfs/procfs file if it exists
w() {
  [ -e "$1" ] || return 0
  chmod +w "$1" 2>/dev/null
  if echo "$2" > "$1" 2>/dev/null; then echo "ok: $1 = $2"; fi
  return 0
}

avail_gov() { cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_available_governors 2>/dev/null; }

# pick_gov g1 g2 ... : first governor that this kernel supports
pick_gov() {
  A=" $(avail_gov) "
  for g in "$@"; do
    case "$A" in *" $g "*) echo "$g"; return 0;; esac
  done
  return 1
}

# setgov NAME : set governor on every CPU policy
setgov() {
  [ -n "$1" ] || return 0
  for p in /sys/devices/system/cpu/cpu[0-9]*/cpufreq; do
    [ -d "$p" ] || continue
    w "$p/scaling_governor" "$1"
  done
}

# Undo what the PowerSaving profile changed (only if it was the active one)
undo_powersave() {
  if [ "$PREV_PROFILE" = "powersave" ]; then
    ok settings put global low_power 0
    ok settings put global window_animation_scale 1.0
    ok settings put global transition_animation_scale 1.0
    ok settings put global animator_duration_scale 1.0
  fi
}
