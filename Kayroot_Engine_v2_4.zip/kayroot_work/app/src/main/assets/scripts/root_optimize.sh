# Conservative root optimization. Avoid undocumented scheduler/sysctl writes: these are kernel-specific and can reduce stability or performance.
# Android's package manager handles app optimization; filesystem trim is attempted only when supported.
if command -v fstrim >/dev/null 2>&1; then
  ok fstrim -v /data
else
  echo "skip: fstrim is not available on this device"
fi
echo "info: unsupported kernel tuning was skipped for device safety"
