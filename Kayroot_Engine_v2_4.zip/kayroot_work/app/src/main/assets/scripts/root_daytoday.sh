# Multitasking (root): balanced governor
G=$(pick_gov "$GOV_DAY" schedutil walt interactive ondemand)
[ -n "$G" ] && setgov "$G"
