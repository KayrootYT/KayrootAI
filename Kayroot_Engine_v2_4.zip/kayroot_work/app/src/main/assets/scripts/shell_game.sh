# GameBooster (Shizuku level)
ok cmd power set-fixed-performance-mode-enabled true
ok settings put global low_power 0
ok settings put global automatic_power_save_mode 0
undo_powersave
