# Cooling needs no privileged command in Shizuku mode: the app closes background apps itself (exclusions honoured).
# Android/OEM thermal management stays in control and nothing is force-stopped.
echo "info: Android thermal management remains enabled"
