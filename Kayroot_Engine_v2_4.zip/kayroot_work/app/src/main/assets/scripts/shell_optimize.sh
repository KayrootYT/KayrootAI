# Use Android's supported background dex optimization job; avoid force-compiling every app or killing all apps.
# The job can run for minutes, so start it detached instead of waiting for it (the 90 s script timeout would report a false failure).
nohup cmd package bg-dexopt-job >/dev/null 2>&1 &
echo "ok: background optimization started (Android runs it in the background; keep charging)"
