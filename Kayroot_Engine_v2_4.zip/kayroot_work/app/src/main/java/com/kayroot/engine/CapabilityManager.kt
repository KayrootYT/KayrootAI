package com.kayroot.engine

import android.app.NotificationManager
import android.content.Context
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import org.json.JSONArray
import org.json.JSONObject

/**
 * Detects what actually works on THIS device. A feature is never shown as working just because its UI exists.
 * Status: supported | partial | permission | shizuku | root | unsupported | failed | untested
 */
class CapabilityManager(private val ctx: Context, private val access: AccessManager) {

    private fun item(id: String, name: String, status: String, detail: String) =
        JSONObject().put("id", id).put("name", name).put("status", status).put("detail", detail)

    fun permissions(): JSONArray {
        val a = JSONArray()
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        a.put(JSONObject().put("id", "overlay").put("name", "Display over other apps")
            .put("why", "Needed only for the floating stats overlay.").put("ok", Settings.canDrawOverlays(ctx)))
        a.put(JSONObject().put("id", "notif").put("name", "Notifications")
            .put("why", "Shows the status of the Auto AI and overlay services.").put("ok", nm.areNotificationsEnabled()))
        a.put(JSONObject().put("id", "battery").put("name", "Unrestricted battery use")
            .put("why", "Lets Auto AI keep running; some phones kill background services otherwise.")
            .put("ok", pm.isIgnoringBatteryOptimizations(ctx.packageName)))
        a.put(JSONObject().put("id", "shizuku").put("name", "Shizuku")
            .put("why", "Unlocks app disable, dexopt, FPS and CPU stats without root.")
            .put("ok", access.shizukuGranted()))
        a.put(JSONObject().put("id", "root").put("name", "Root")
            .put("why", "Only for governors, bypass charging and kernel tweaks. Checked on request.")
            .put("ok", access.rootOk))
        return a
    }

    fun scan(): JSONArray {
        val probe = ctx.assets.open("scripts/probe_caps.sh").bufferedReader().use { it.readText() }
        val r = access.execScript(probe, 20_000)
        val m = r.out.lineSequence().filter { it.contains("=") }
            .associate { it.substringBefore("=") to it.substringAfter("=").trim() }
        val probeOk = m.isNotEmpty()
        val modeReady = when (access.mode) {
            Mode.BASIC -> true
            Mode.SHIZUKU -> access.shizukuGranted()
            Mode.ROOT -> access.checkRoot()
        }
        val rootReady = access.mode == Mode.ROOT && modeReady && probeOk
        val a = JSONArray()
        fun yes(k: String) = m[k] == "1"
        fun privilegedStatus(key: String): String = when {
            probeOk && yes(key) -> "supported"
            !modeReady -> "permission"
            access.mode == Mode.BASIC -> "shizuku"
            !probeOk -> "failed"
            else -> "unsupported"
        }

        a.put(item("cpu_usage", "CPU usage", privilegedStatus("procstat"),
            if (yes("procstat")) "Probe can read /proc/stat in the selected mode." else "The selected mode could not read /proc/stat; the value will be N/A."))
        a.put(item("cpu_freq", "CPU frequency", privilegedStatus("cpufreq"),
            if (yes("cpufreq")) "CPU frequency node is readable." else "scaling_cur_freq is not readable in this mode/device."))
        a.put(item("gpu", "GPU usage / frequency", privilegedStatus("gpu_kgsl"),
            if (yes("gpu_kgsl")) "A GPU metrics node was detected; exact metrics still depend on the driver." else "No supported GPU metrics node was detected; shown as N/A."))
        val thermalStatus = when {
            yes("thermal") -> "supported"
            Build.VERSION.SDK_INT >= 29 -> "partial"
            else -> "unsupported"
        }
        a.put(item("thermal", "Temperature & thermal status", thermalStatus,
            "Android thermal status and battery temperature are separate sources. CPU sensor readings may be unavailable."))
        a.put(item("battery", "Battery info", "partial", "Battery level/status are available through Android; current, power, cycles and capacity may be N/A on this device."))
        a.put(item("ram", "RAM info", "supported", "ActivityManager provides memory totals; optional /proc/meminfo fields may be unavailable."))
        a.put(item("fps", "FPS measurement", when {
            !modeReady -> "permission"
            access.mode == Mode.BASIC -> "shizuku"
            !probeOk -> "failed"
            yes("sf") -> "partial"
            else -> "unsupported"
        }, "SurfaceFlinger frame timestamps are device/app dependent and may not expose reliable FPS for every game."))
        a.put(item("overlay", "Floating overlay", if (Settings.canDrawOverlays(ctx)) "supported" else "permission", "Needs 'Display over other apps'."))
        a.put(item("app_manage", "App list / launch / uninstall", "supported", "App listing and launching use Android APIs; uninstall uses the system confirmation flow."))
        a.put(item("app_disable", "Disable apps (debloat)", when {
            !modeReady -> "permission"
            access.mode == Mode.BASIC -> "shizuku"
            !probeOk -> "failed"
            yes("pm") -> "supported"
            else -> "unsupported"
        }, "Only user-selected packages should be changed. Protected/system-critical packages must be blocked."))
        a.put(item("cache", "Cache cleanup", when {
            access.mode == Mode.BASIC -> "partial"
            !modeReady -> "permission"
            !probeOk -> "failed"
            else -> "partial"
        }, if (access.mode == Mode.BASIC) "Only this app's own cache and limited background management." else "pm trim-caches availability varies; this is not a guarantee of faster performance."))
        a.put(item("dexopt", "ART compile / dexopt", when {
            !modeReady -> "permission"
            access.mode == Mode.BASIC -> "shizuku"
            !probeOk -> "failed"
            yes("dexopt") -> "supported"
            else -> "unsupported"
        }, "cmd package compile support is probed; compilation may take time and consume battery."))
        a.put(item("fstrim", "Filesystem trim", when {
            !modeReady -> "permission"
            access.mode == Mode.BASIC -> "shizuku"
            !probeOk -> "failed"
            rootReady && yes("fstrim") -> "supported"
            yes("smtrim") -> "partial"
            else -> "unsupported"
        }, "Actual permission and filesystem support depend on Android version and device."))
        a.put(item("cooldown", "Emergency cooldown", when {
            access.mode == Mode.BASIC -> "partial"
            !modeReady -> "permission"
            else -> "partial"
        }, "May apply battery saver or supported controls; never disables Android's native thermal protection."))
        a.put(item("governor", "CPU governor", when {
            !modeReady -> "permission"
            !rootReady -> "root"
            else -> "untested"
        }, "Root-only; shown as untested until a real apply-and-readback succeeds."))
        a.put(item("bypass", "Bypass charging", when {
            !modeReady -> "permission"
            !rootReady -> "root"
            yes("bypass") -> "partial"
            else -> "unsupported"
        }, "Kernel-node presence is only a preliminary probe; verify readback after applying. Many devices do not support it."))
        return a
    }
}
