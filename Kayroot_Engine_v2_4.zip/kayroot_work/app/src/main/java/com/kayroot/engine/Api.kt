package com.kayroot.engine

import android.content.Context
import android.provider.Settings
import org.json.JSONArray
import org.json.JSONObject

/** Single entry point for everything the WebUI asks for: KayrootApp.call(action, argsJson, callback). */
class Api(
    private val ctx: Context,
    private val access: AccessManager,
    private val tweaks: Tweaks,
    private val features: Features
) {
    private val prefs = ctx.getSharedPreferences("kayroot", Context.MODE_PRIVATE)
    private val pkgRe = Regex("^[A-Za-z0-9_]+(\\.[A-Za-z0-9_]+)+$")
    /** Package names coming from the WebView are validated before they reach any shell or PackageManager call. */
    private fun pkg(a: JSONObject): String = a.optString("pkg").takeIf { pkgRe.matches(it) } ?: ""
    private val monitor = Monitor(ctx, access)
    private val apps = Apps(ctx, access)
    private val extras = Extras(ctx, access, tweaks)
    private val caps = CapabilityManager(ctx, access)

    /** Called once at app start: finishes an emergency-cooldown restore that was lost when the process died. */
    fun resumePending() = extras.resumePending()

    fun status(): JSONObject = JSONObject(access.statusJson()).apply {
        put("profile", prefs.getString("ui_profile", "") ?: "")
        put("ai", JSONObject().put("on", prefs.getBoolean("ai_on", false))
            .put("profile", AutoAiService.current).put("reason", AutoAiService.reason))
        put("aiMode", prefs.getString("ai_mode", "") ?: "")
        put("lastOpt", prefs.getLong("last_opt", 0L))
        put("boot", prefs.getBoolean("boot_apply", true))
        put("debug", prefs.getBoolean("debug", false))
        put("overlay", OverlayService.running)
    }

    // operations that are written to the persistent history
    private fun logLabel(action: String, a: JSONObject): String? = when (action) {
        "profile" -> "Profile " + a.optString("name")
        "ai_mode" -> "AI mode " + a.optString("name")
        "ai_stop" -> "AI engine stopped"
        "ai_restart" -> "AI engine restarted"
        "reset" -> "Reset"
        "clean" -> "Cleaner"
        "cool" -> "Cooling"
        "optimize" -> "Optimizer"
        "netrefresh" -> "Net Refresh"
        "toggle_set" -> "Toggle " + a.optString("key") + (if (a.optBoolean("on")) " on" else " off")
        "gov_set" -> "Governor " + a.optString("name")
        "extra_run" -> "Extra optimization " + a.optString("kind")
        "extra_sched" -> "Maintenance schedule"
        "debloat_apply" -> "Debloat " + a.optString("action")
        "cooldown_restore" -> "Cooldown restore"
        "overlay_start" -> "Overlay start"
        "logcat_clear" -> "Logcat buffers cleared"
        "backup_import" -> "Settings restored from backup"
        "app_profile_set" -> "Per-app profile " + a.optString("pkg")
        else -> null
    }

    fun handle(action: String, a: JSONObject): JSONObject {
        val out = route(action, a)
        val label = logLabel(action, a)
        if (label != null && !out.optBoolean("confirm", false)) {
            val ok = out.optBoolean("ok", false)
            val msg = out.optString("msg", "")
            val dbg = prefs.getBoolean("debug", false)
            OpLog.add(ctx, if (ok) label + (if (msg.isNotBlank() && dbg) " - $msg" else "") else "$label failed: $msg", ok)
            if (ok && action in setOf("profile", "ai_mode", "clean", "cool", "optimize", "netrefresh")) {
                prefs.edit().putLong("last_opt", System.currentTimeMillis()).apply()
            }
        }
        return out
    }

    private fun data(x: Any) = JSONObject().put("ok", true).put("data", x)

    private fun route(action: String, a: JSONObject): JSONObject = when (action) {
        "profile" -> profile(a.optString("name"))
        "ai_mode" -> aiMode(a.optString("name"))
        "ai_stop" -> { stopAi(); prefs.edit().putString("ui_profile", "").putString("ai_mode", "").apply(); ok("AI engine stopped") }
        "ai_restart" -> aiRestart()
        "reset" -> {
            stopAi()
            val r = tweaks.reset()
            if (r.errno == 0) prefs.edit().putString("ui_profile", "").putString("ai_mode", "").apply()
            res(r, "Profiles reset")
        }
        "clean" -> res(tweaks.clean(), "Cleaner finished")
        "cool" -> res(tweaks.cool(), "Cooling finished")
        "optimize" -> res(tweaks.optimize(), "Optimizer started")
        "netrefresh" -> res(tweaks.netRefresh(), "Network refreshed")
        "toggle_get_all" -> JSONObject().put("ok", true).put("data", features.toggleGetAll())
        "toggle_set" -> res(features.toggleSet(a.optString("key"), a.optBoolean("on")))
        "gov_info" -> features.govInfo()
        "gov_set" -> {
            val r = tweaks.setGovernor(a.optString("name"))
            if (r.errno == 0) {
                when (prefs.getString("ui_profile", "")) {
                    "powersave" -> tweaks.saveGovernorPref("governor_powersave", a.optString("name"))
                    "game", "auto" -> {}
                    else -> tweaks.saveGovernorPref("governor_daytoday", a.optString("name"))
                }
            }
            res(r)
        }
        "boot_set" -> { prefs.edit().putBoolean("boot_apply", a.optBoolean("on")).apply(); ok("") }
        "debug_set" -> { prefs.edit().putBoolean("debug", a.optBoolean("on")).apply(); ok("") }

        // ---- monitoring
        "mon_sample" -> {
            val sample = monitor.sample()
            recordPerformanceSample(sample)
            data(sample)
        }
        "mon_reset" -> { monitor.resetCpu(); ok("") }
        "batt_info" -> data(monitor.battery().put("battOptIgnored", isIgnoringBattOpt()))
        "perf_history_get" -> data(performanceHistory())
        "perf_baseline_save" -> {
            val sample = monitor.sample()
            val baseline = performanceSnapshot(sample)
            baseline.put("ts", System.currentTimeMillis())
            prefs.edit().putString("perf_baseline", baseline.toString()).apply()
            JSONObject().put("ok", true).put("msg", "Baseline saved").put("data", baseline)
        }
        "perf_compare" -> comparePerformance()
        "perf_history_clear" -> { prefs.edit().remove("perf_history").remove("perf_baseline").apply(); ok("Performance history and baseline cleared") }
        "battery_history_get" -> data(batteryHistory())
        "battery_history_clear" -> { prefs.edit().remove("battery_history").apply(); ok("Battery history cleared") }

        // ---- overlay
        "overlay_cfg_get" -> data(JSONObject()
            .put("running", OverlayService.running)
            .put("perm", Settings.canDrawOverlays(ctx))
            .put("stats", prefs.getString("ov_stats", "fps,cpu,ram,bat,temp"))
            .put("alpha", prefs.getInt("ov_alpha", 80))
            .put("size", prefs.getInt("ov_size", 12))
            .put("interval", prefs.getInt("ov_interval", 1500)))
        "overlay_cfg_set" -> {
            val e = prefs.edit()
            if (a.has("stats")) e.putString("ov_stats", a.optString("stats").filter { it.isLetter() || it == ',' })
            if (a.has("alpha")) e.putInt("ov_alpha", a.optInt("alpha", 80).coerceIn(20, 100))
            if (a.has("size")) e.putInt("ov_size", a.optInt("size", 12).coerceIn(9, 20))
            if (a.has("interval")) e.putInt("ov_interval", a.optInt("interval", 1500).coerceIn(500, 10_000))
            e.apply()
            if (OverlayService.running) {   // apply immediately
                OverlayService.stop(ctx)
                try { Thread.sleep(400) } catch (_: InterruptedException) {}
                OverlayService.start(ctx)
            }
            ok("")
        }
        "overlay_start" ->
            if (!Settings.canDrawOverlays(ctx)) JSONObject().put("ok", false).put("perm", "overlay")
                .put("msg", "Allow 'Display over other apps' for Kayroot first")
            else { OverlayService.start(ctx); ok("Overlay started") }
        "overlay_stop" -> { OverlayService.stop(ctx); ok("Overlay stopped") }

        // ---- apps
        "apps_list" -> data(apps.list())
        "app_icons" -> data(apps.icons(a.optJSONArray("pkgs") ?: JSONArray()))
        "app_details" -> if (pkg(a).isEmpty()) fail("Invalid package name") else apps.details(pkg(a))
        "app_launch" -> if (pkg(a).isEmpty()) fail("Invalid package name") else apps.launch(pkg(a))
        "app_settings" -> if (pkg(a).isEmpty()) fail("Invalid package name") else apps.openSettings(pkg(a))
        "app_uninstall" -> if (pkg(a).isEmpty()) fail("Invalid package name") else apps.uninstall(pkg(a))
        "excl_get" -> data(try { JSONArray(prefs.getString("excl", "[]")) } catch (e: Exception) { JSONArray() })
        "excl_set" -> {
            val list = a.optJSONArray("list") ?: JSONArray()
            val clean = JSONArray()
            for (i in 0 until list.length()) clean.put(list.optString(i))
            prefs.edit().putString("excl", clean.toString()).apply()
            ok("")
        }
        "debloat_list" -> data(apps.candidates())
        "debloat_apply" -> {
            val l = a.optJSONArray("pkgs") ?: JSONArray()
            val pk = ArrayList<String>()
            for (i in 0 until l.length()) pk.add(l.optString(i))
            val r = apps.apply(a.optString("action"), pk)
            var good = 0
            for (i in 0 until r.length()) if (r.getJSONObject(i).optBoolean("ok")) good++
            JSONObject().put("ok", good > 0).put("data", r).put("msg", "$good of ${r.length()} done")
        }

        // ---- extra optimization / cooldown
        "extra_run" -> extras.run(a.optString("kind"), a.optBoolean("force"))
        "extra_status" -> extras.status(a.optString("kind"))
        "extra_sched_get" -> extras.scheduleGet()
        "extra_sched" -> extras.scheduleSet(a.optBoolean("on"))
        "cooldown" -> {
            val l = a.optJSONArray("steps") ?: JSONArray()
            val s = ArrayList<String>()
            for (i in 0 until l.length()) s.add(l.optString(i))
            extras.cooldown(s)
        }
        "cooldown_get" -> data(extras.cooldownPending())
        "cooldown_restore" -> extras.restore()

        // ---- logs / history
        "log_get" -> data(OpLog.list(ctx))
        "log_clear" -> { OpLog.clear(ctx); ok("History cleared") }
        "log_view" -> {
            if (access.mode == Mode.BASIC) data("Basic mode can only see this app's own log lines.\n" +
                access.execScript("logcat -d -t 60 2>&1 | tail -n 60", 10_000).out.take(5000))
            else data(access.execScript("logcat -d -t 80 '*:W' 2>&1 | tail -n 80", 15_000).out.take(6000))
        }
        "logcat_clear" -> {
            val r = access.execScript("logcat -b main -b system -b crash -c", 10_000)
            if (r.errno == 0) ok("Log buffers cleared (security/audit logs untouched)") else fail(r.err.trim().ifEmpty { "Not permitted in this mode" })
        }

        // ---- Auto AI configuration (custom rules, night schedule, user game list)
        "ai_cfg_get" -> data(JSONObject()
            .put("cfg", AutoAiRules.toJson(AutoAiRules.parse(prefs.getString("ai_cfg", null))))
            .put("games", try { JSONArray(prefs.getString("ai_games", "[]")) } catch (e: Exception) { JSONArray() }))
        "ai_cfg_set" -> {
            val cfg = AutoAiRules.fromJson(a.optJSONObject("cfg"))   // sanitised + clamped
            prefs.edit().putString("ai_cfg", AutoAiRules.toJson(cfg).toString()).apply()
            ok("Auto AI rules saved")
        }
        "games_set" -> {
            val list = a.optJSONArray("list") ?: JSONArray()
            val clean = JSONArray()
            for (i in 0 until minOf(list.length(), 500)) list.optString(i).takeIf { pkgRe.matches(it) }?.let { clean.put(it) }
            prefs.edit().putString("ai_games", clean.toString()).apply()
            ok("Game list updated")
        }
        "app_profiles_get" -> data(try { JSONObject(prefs.getString("ai_app_profiles", "{}")) } catch (_: Exception) { JSONObject() })
        "app_profile_set" -> {
            val packageName = pkg(a)
            val profileName = a.optString("profile", "")
            if (packageName.isEmpty()) fail("Invalid package name")
            else if (profileName.isNotEmpty() && profileName !in AutoAiRules.PROFILES) fail("Unknown profile")
            else {
                val map = try { JSONObject(prefs.getString("ai_app_profiles", "{}")) } catch (_: Exception) { JSONObject() }
                if (profileName.isEmpty()) map.remove(packageName) else map.put(packageName, profileName)
                // Bound storage and avoid retaining profiles for an unbounded number of packages.
                val clean = JSONObject(); val keys = map.keys(); var count = 0
                while (keys.hasNext() && count < 500) { val key = keys.next(); if (pkgRe.matches(key) && map.optString(key) in AutoAiRules.PROFILES) { clean.put(key, map.optString(key)); count++ } }
                prefs.edit().putString("ai_app_profiles", clean.toString()).apply()
                ok(if (profileName.isEmpty()) "Per-app profile removed" else "Per-app profile saved")
            }
        }

        // ---- backup / restore / crash log
        "backup_export" -> data(Backup.export(prefs, a.optJSONObject("ui")).toString(2))
        "backup_import" -> {
            val text = a.optString("text")
            if (text.length > 200_000) fail("File is too large to be a Kayroot backup")
            else {
                val n = Backup.import(prefs, text)
                if (n < 0) fail("This is not a Kayroot backup file")
                else JSONObject().put("ok", true).put("msg", "Restored $n settings").put("ui", try { JSONObject(text).optJSONObject("ui") ?: JSONObject() } catch (e: Exception) { JSONObject() })
            }
        }
        "crash_get" -> data(CrashLog.read(ctx))
        "crash_clear" -> { CrashLog.clear(ctx); ok("Crash log cleared") }

        // ---- capability + permissions
        "caps_scan" -> data(caps.scan())
        "perm_status" -> data(caps.permissions())
        else -> fail("Unknown action")
    }


    /** Persist a small, bounded local history. This is device-local and never uploaded. */
    private fun recordPerformanceSample(sample: JSONObject) {
        try {
            val history = JSONArray(prefs.getString("perf_history", "[]"))
            val b = sample.optJSONObject("battery") ?: JSONObject()
            val ram = sample.optJSONObject("ram") ?: JSONObject()
            val row = JSONObject()
                .put("ts", System.currentTimeMillis())
                .putN("cpuPct", sample.opt("cpuPct").takeUnless { it == JSONObject.NULL })
                .putN("ramPct", ram.opt("pct").takeUnless { it == JSONObject.NULL })
                .putN("battery", b.opt("level").takeUnless { it == JSONObject.NULL || (it as? Number)?.toInt()?.let { n -> n < 0 } == true })
                .putN("batteryTemp", b.opt("tempC").takeUnless { it == JSONObject.NULL || (it as? Number)?.toDouble()?.let { n -> n <= 0.0 } == true })
                .putN("cpuTemp", sample.opt("cpuTemp").takeUnless { it == JSONObject.NULL })
                .put("thermal", sample.optString("thermal", "N/A"))
            val out = JSONArray()
            val start = (history.length() - 499).coerceAtLeast(0)
            for (i in start until history.length()) out.put(history.getJSONObject(i))
            out.put(row)
            prefs.edit().putString("perf_history", out.toString()).apply()
        } catch (_: Exception) {
            // Monitoring must continue even if history storage is corrupted or temporarily unavailable.
        }
    }

    private fun performanceSnapshot(sample: JSONObject): JSONObject {
        val ram = sample.optJSONObject("ram") ?: JSONObject()
        val battery = sample.optJSONObject("battery") ?: JSONObject()
        return JSONObject()
            .putN("cpuPct", sample.opt("cpuPct").takeUnless { it == JSONObject.NULL })
            .putN("ramPct", ram.opt("pct").takeUnless { it == JSONObject.NULL })
            .putN("battery", battery.opt("level").takeUnless { it == JSONObject.NULL || (it as? Number)?.toInt()?.let { n -> n < 0 } == true })
            .putN("batteryTemp", battery.opt("tempC").takeUnless { it == JSONObject.NULL || (it as? Number)?.toDouble()?.let { n -> n <= 0.0 } == true })
            .putN("cpuTemp", sample.opt("cpuTemp").takeUnless { it == JSONObject.NULL })
            .put("thermal", sample.optString("thermal", "N/A"))
    }

    private fun comparePerformance(): JSONObject {
        val raw = prefs.getString("perf_baseline", null) ?: return fail("Save a baseline first")
        val baseline = try { JSONObject(raw) } catch (_: Exception) { return fail("Saved baseline is invalid") }
        val currentSample = monitor.sample()
        val current = performanceSnapshot(currentSample).put("ts", System.currentTimeMillis())
        val keys = listOf("cpuPct", "ramPct", "battery", "batteryTemp", "cpuTemp")
        val delta = JSONObject()
        for (key in keys) {
            val before = baseline.opt(key); val after = current.opt(key)
            val bv = (before as? Number)?.toDouble(); val av = (after as? Number)?.toDouble()
            delta.putN(key, if (bv != null && av != null) av - bv else null)
        }
        return JSONObject().put("ok", true).put("data", JSONObject()
            .put("baseline", baseline).put("current", current).put("delta", delta)
            .put("baselineTs", baseline.optLong("ts", 0L)).put("currentTs", current.optLong("ts", 0L)))
    }

    private fun performanceHistory(): JSONArray = try {
        JSONArray(prefs.getString("perf_history", "[]"))
    } catch (_: Exception) { JSONArray() }

    private fun batteryHistory(): JSONArray = try {
        JSONArray(prefs.getString("battery_history", "[]"))
    } catch (_: Exception) { JSONArray() }

    private fun isIgnoringBattOpt(): Boolean = try {
        (ctx.getSystemService(Context.POWER_SERVICE) as android.os.PowerManager).isIgnoringBatteryOptimizations(ctx.packageName)
    } catch (e: Exception) { false }

    private fun profile(name: String): JSONObject {
        if (name == "auto") {
            if (access.mode == Mode.BASIC) return fail("Auto AI needs Shizuku or Root. Enable it in Access Mode.")
            prefs.edit().putBoolean("ai_on", true).putString("ui_profile", "auto").putString("ai_mode", "auto").apply()
            AutoAiService.start(ctx)
            return ok("")
        }
        stopAi()
        val r = tweaks.profile(name)
        if (r.errno == 0) prefs.edit().putString("ui_profile", name).putString("ai_mode",
            when (name) { "powersave" -> "power"; "game" -> "perf"; else -> "" }).apply()
        return res(r)
    }

    /** power = Power Save, auto = adaptive rules engine, perf = Performance. */
    private fun aiMode(name: String): JSONObject = when (name) {
        "power" -> profile("powersave")
        "perf" -> profile("game")
        "auto" -> profile("auto")
        else -> fail("Unknown mode")
    }

    private fun aiRestart(): JSONObject {
        if (!prefs.getBoolean("ai_on", false)) return fail("Auto AI is not running")
        AutoAiService.stop(ctx)
        try { Thread.sleep(600) } catch (_: InterruptedException) {}
        prefs.edit().putBoolean("ai_on", true).apply()
        AutoAiService.start(ctx)
        return ok("AI engine restarted")
    }

    private fun stopAi() {
        if (prefs.getBoolean("ai_on", false)) {
            prefs.edit().putBoolean("ai_on", false).apply()
            AutoAiService.stop(ctx)
        }
    }

    private fun ok(msg: String) = JSONObject().put("ok", true).put("msg", msg)
    private fun fail(msg: String) = JSONObject().put("ok", false).put("msg", msg)

    private fun res(r: ExecResult, okMsg: String = ""): JSONObject {
        val line = r.out.lineSequence()
            .firstOrNull { it.startsWith("ok: background") || it.startsWith("ok: app caches") }
            ?.removePrefix("ok: ")
        return JSONObject().put("ok", r.errno == 0)
            .put("msg", if (r.errno == 0) (line ?: okMsg) else r.err.trim().ifEmpty { "Failed" })
    }
}
