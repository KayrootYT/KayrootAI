package com.kayroot.engine

import android.app.job.JobParameters
import android.app.job.JobService

/** Runs the background dexopt job when Android decides conditions fit (charging + idle). Respects the 6h gap. */
class MaintenanceJob : JobService() {
    override fun onStartJob(params: JobParameters): Boolean {
        Thread {
            try {
                val access = AccessManager(this)
                if (access.mode == Mode.BASIC) {
                    OpLog.add(this, "Scheduled maintenance skipped: needs Shizuku/Root", false)
                } else {
                    val r = Extras(this, access, Tweaks(this, access)).run("bgdexopt", false)
                    OpLog.add(this, "Scheduled maintenance: " + r.optString("msg"), r.optBoolean("ok"))
                }
            } catch (e: Exception) {
                OpLog.add(this, "Scheduled maintenance failed: " + (e.message ?: "error"), false)
            } finally {
                jobFinished(params, false)
            }
        }.start()
        return true
    }

    override fun onStopJob(params: JobParameters): Boolean = false
}
