package com.kayroot.engine

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Local-only crash log. Nothing is ever uploaded: the user can open it in Settings and share it manually.
 */
object CrashLog {
    private const val FILE = "crash.log"
    private const val MAX = 24_000

    fun install(ctx: Context) {
        val app = ctx.applicationContext
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        if (previous is Handler) return   // already installed
        Thread.setDefaultUncaughtExceptionHandler(Handler(app, previous))
    }

    private class Handler(val ctx: Context, val previous: Thread.UncaughtExceptionHandler?) : Thread.UncaughtExceptionHandler {
        override fun uncaughtException(t: Thread, e: Throwable) {
            try { add(ctx, "Uncaught exception in thread '${t.name}'", e) } catch (_: Throwable) {}
            previous?.uncaughtException(t, e)
        }
    }

    @Synchronized
    fun add(ctx: Context, what: String, e: Throwable? = null) {
        val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
        val entry = StringBuilder("[$stamp] $what\n")
        if (e != null) entry.append(android.util.Log.getStackTraceString(e)).append('\n')
        val f = File(ctx.filesDir, FILE)
        val old = if (f.exists()) f.readText() else ""
        f.writeText((old + entry).takeLast(MAX))
    }

    fun read(ctx: Context): String {
        val f = File(ctx.filesDir, FILE)
        val header = "Kayroot Engine ${BuildConfig.VERSION_NAME} | Android ${android.os.Build.VERSION.RELEASE} (API ${android.os.Build.VERSION.SDK_INT}) | ${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}\n\n"
        return if (f.exists() && f.length() > 0) header + f.readText() else ""
    }

    fun clear(ctx: Context) { File(ctx.filesDir, FILE).delete() }
}
