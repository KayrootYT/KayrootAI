# Kayroot Engine — Android app (v2.4)

Kayroot Engine is an Android utility with Basic, Shizuku and Root execution modes. Device access and feature availability depend on Android version, OEM restrictions, Shizuku permission, root availability and kernel support. A feature is not guaranteed merely because its control appears in the UI.

## Build with GitHub Actions

1. Commit the **contents** of this project folder to the repository (including `app/`, `build.gradle.kts` and `settings.gradle.kts`).
2. Open **Actions → Kayroot Engine Android CI** and run the workflow, or push to `main`/`master`.
3. Download the APK and SHA-256 checksum from the workflow artifacts.
4. Pull requests run unit tests, lint and the APK build. A version tag (`v2.4`, for example) publishes a GitHub Release only when persistent signing secrets are configured.

### Persistent signing (required for distributable releases)

Create and safely retain your own release keystore. Configure these repository Actions secrets:

- `KEYSTORE_BASE64` — base64-encoded keystore file
- `KEYSTORE_PASSWORD`
- `KEY_ALIAS`
- `KEY_PASSWORD`

The same private key must be used for every update. **Never commit the keystore or passwords to the repository.** When secrets are absent, CI creates a development APK signed with Gradle's debug key and labels it `debug-signed`; it is not suitable for publishing as a stable upgrade. Tagged releases intentionally fail without the persistent signing key.

## Current feature areas

- Access modes: Basic, Shizuku and Root, with permission/status checks.
- Profiles and Auto AI rules, night schedule, game list, per-app profiles, temperature and battery thresholds.
- Live CPU/RAM/battery/thermal monitoring where readings are exposed by Android/device interfaces.
- FPS overlay using SurfaceFlinger when permission and device support allow it.
- App management, debloat preview, cache maintenance, dexopt/trim requests, supported system toggles and root-only kernel controls.
- Safe settings backup/restore, local operation/crash logs, a bounded on-device performance history with CSV export, baseline/after comparison reports, and best-effort background battery samples for recent screen-off drain estimates.
- Capability scan with supported/partial/permission-required/Shizuku-required/root-required/unsupported/failed/untested statuses.

## Important limitations

- Basic mode cannot bypass Android's protected APIs or kernel permissions.
- Shizuku is not root; many sysfs writes and charging controls require root and device-specific kernel support.
- CPU/GPU/FPS sensors may be unavailable. Unavailable values are shown as N/A rather than estimated as real measurements.
- Battery health category is not a battery-capacity test; capacity is only an estimate when Android exposes a charge counter.
- Android may stop background services due to battery policy. Auto AI does not override Android thermal protections.
- Performance history is stored locally in app preferences and is capped at 500 samples. Performance sampling occurs only while the monitor is active; background battery history is best-effort and Android may delay/skip jobs.

## Development verification

GitHub CI runs `:app:testDebugUnitTest`, `:app:lintDebug` and `:app:assembleRelease`. The local source archive was updated to v2.4, but a successful device-level runtime test cannot be claimed until the workflow and physical-device checks complete.
