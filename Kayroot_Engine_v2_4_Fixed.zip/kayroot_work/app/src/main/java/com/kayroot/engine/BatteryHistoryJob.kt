package com.kayroot.engine

import android.app.JobInfo
import android.app.JobScheduler
import android.app.job.JobParameters
import android.app.job.JobService
import android.content.ComponentName
import android.content.Context
import android.os.PowerManager
import org.json.JSONArray
import org.json.JSONObject

/** Best-effort background battery samples; Android schedules these no more often than its job policy allows. */
class BatteryHistoryJob : JobService() {
    companion object {
        const val JOB_ID = 4202
        private const val PERIOD_MS = 15 * 60 * 1000L

        fun schedule(context: Context) {
            try {
                val scheduler = context.getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler
                val job = JobInfo.Builder(JOB_ID, ComponentName(context, BatteryHistoryJob::class.java))
                    .setPeriodic(PERIOD_MS)
                    .setPersisted(true)
                    .build()
                scheduler.schedule(job)
            } catch (_: Exception) {
                // Background sampling is optional; the foreground monitor and app must still work.
            }
        }

        fun record(context: Context) {
            val prefs = context.getSharedPreferences("kayroot", Context.MODE_PRIVATE)
            val b = readBattery(context)
            val power = context.getSystemService(Context.POWER_SERVICE) as PowerManager
            val row = JSONObject()
                .put("ts", System.currentTimeMillis())
                .put("level", if (b.level in 0..100) b.level else JSONObject.NULL)
                .put("tempC", if (b.temp > 0) b.temp else JSONObject.NULL)
                .put("charging", b.charging)
                .put("screenOn", power.isInteractive)
            val history = try { JSONArray(prefs.getString("battery_history", "[]")) } catch (_: Exception) { JSONArray() }
            val out = JSONArray()
            val start = (history.length() - 499).coerceAtLeast(0)
            for (i in start until history.length()) {
                try { out.put(history.getJSONObject(i)) } catch (_: Exception) {}
            }
            out.put(row)
            prefs.edit().putString("battery_history", out.toString()).apply()
        }
    }

    override fun onStartJob(params: JobParameters): Boolean {
        Thread {
            try { record(applicationContext) } catch (_: Exception) {}
            jobFinished(params, false)
        }.start()
        return true
    }

    override fun onStopJob(params: JobParameters): Boolean = true
}
